#include <stdio.h>
#include <stdlib.h>

//2

int main(){
    return 0;
}
