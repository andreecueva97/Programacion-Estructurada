#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//1
struct sParcela{
    int id;
    int idCategoria;
    int tamanio;
    double valor;
};
typedef struct sParcela estructuraDeParcela;

struct sCategoria{
    int id;
    char descripcion;
    char
}

void carga_suma(){}

int main(){
}
