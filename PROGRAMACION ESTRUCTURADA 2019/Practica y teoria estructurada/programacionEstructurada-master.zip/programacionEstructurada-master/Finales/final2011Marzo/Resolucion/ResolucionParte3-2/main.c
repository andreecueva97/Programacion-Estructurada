#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//2

int main(){
    return 0;
}
