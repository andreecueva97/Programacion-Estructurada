#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
int cargarText(char x[102]);
void imprimirText(char x[102]);
void normalizar(char x[102],int y);
int main(){
    int control;
    char texto[102];
    control=0;
    printf("ingrese texto:");
    control=cargarText(texto);
    texto[control]='\0';
    imprimirText(texto);
    normalizar(texto,control);
    imprimirText(texto);
    return 0;
}
int cargarText(char x[102]){
    int control;
    control=0;
    char caracter;
    caracter=getche();
    while(caracter!='\r' && control!=101){
        x[control]=caracter;
        caracter=getche();
        control++;
    }
    return control;
}
void imprimirText(char x[102]){
    printf("\n%s",x);
}
void normalizar(char x[102],int y){
    int i,j;
    i=0;
    if((x[0])>=97 && x[0]<=122){
       x[0]-=32;
    }
    while(i<y){
        if(x[i]==' ' && (x[i+1]==' ' || x[i-1]==' ')){
            for(j=i;j<y;j++)
                x[j]=x[j+1];
                y--;
        } else {
            i++;
        }
    }
    if(x[y-1]!='.'){
        x[y]='.';
        x[y+1]='\0';

    }
}
