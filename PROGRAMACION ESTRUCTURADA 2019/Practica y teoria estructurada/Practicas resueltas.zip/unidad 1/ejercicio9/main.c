#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
void cargarMatText(char x[5][5],int y,int z);
void imprimirMatText(char x[5][5]);
void ordenarMatText(char x[5][5],int y,int z);
int main(){
    char matriz[5][5];
    printf("ingrese letras:");
    cargarMatText(matriz,5,5);
    imprimirMatText(matriz);
    ordenarMatText(matriz,5,5);
    imprimirMatText(matriz);
    return 0;
}
void cargarMatText(char x[5][5],int y,int z){
    int f=0,c=0;
    char caracter=' ';
    while(f!=y && caracter!='\r'){
        while(c!=z && caracter!='\r'){
            caracter=getche();
            if(caracter=='\r' || c==z-1){
                x[f][c]='\0';
            } else {
                x[f][c]=caracter;
            }
            c++;
        }
        printf("\n");
        if(caracter=='\r' && c>1){
            caracter=' ';
        }
        f++;
        c=0;
    }
}
void imprimirMatText(char x[5][5]){
    int f=0;
    while(x[f][0]!='\0'){
        printf("%s",x[f]);
        printf("\n");
        f++;
    }
}
void ordenarMatText(char x[5][5],int y,int z){
    int i=0,j=0,f=0,c=j,aux,alpha1=0,alpha2;
    while(i!=y && x[i][j]!='\0'){
        if((x[i][j])>=65 && x[i][j]<=90){
            x[i][j]+=32;
            alpha1=1;
        }
        while(f<y && x[f][c]!='\0'){
            while(c<z && x[f][c]!='\0'){
                if((x[f][c])>=65 && x[f][c]<=90){
                    x[f][c]+=32;
                    alpha2=1;
                }
                if(x[i][j]>x[f][c]){
                    aux=x[f][c];
                    x[f][c]=x[i][j];
                    x[i][j]=aux;
                }
                if(alpha2==1){
                    x[f][c]-=32;
                    alpha2=0;
                }
                c++;
            }
            f++;
            c=0;
        }
        if(alpha1==1){
            x[i][j]-=32;
            alpha1=0;
        }
        j++;
        if(j==z || x[i][j]=='\0'){
            i++;
            j=0;
        }
        f=i;
        c=j;

    }
}
