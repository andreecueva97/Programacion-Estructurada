#include <stdio.h>
#include <stdlib.h>
void cargarMat(int x[3][3],int y,int z);
void imprimirMat(int x[3][3],int y,int z);
int promMat(int x[3][3],int y,int z);
int main(){
    int resultado,filas=3,columnas=3;
    int matriz[filas][columnas];
    printf("ingrese numeros:");
    cargarMat(matriz,filas,columnas);
    imprimirMat(matriz,filas,columnas);
    resultado=promMat(matriz,filas,columnas);
    printf("\nEl promedio de toda la matriz es: %d",resultado);
    return 0;
}
void cargarMat(int x[3][3],int y,int z){
    int f=0,c=0,num;
    while(f!=y){
        while(c!=z){
            scanf("%d",&num);
            x[f][c]=num;
            c++;
        }
        f++;
        c=0;
    }
}
void imprimirMat(int x[3][3],int y,int z){
    int f=0,c=0;
    while(f!=y){
        while(c!=z){
            printf("%d ",x[f][c]);
            c++;
        }
        printf("\n");
        f++;
        c=0;
    }
}
int promMat(int x[3][3],int y,int z){
    int f=0,c=0,sumatoria=0,promedio;
    while(f!=y){
        while(c!=z){
            sumatoria+=x[f][c];
            c++;
        }
        f++;
        promedio=f*c;
        c=0;
    }
    return sumatoria/promedio;
}
