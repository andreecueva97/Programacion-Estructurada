#include <stdio.h>
#include <stdlib.h>
void cargarMatTextDeArch(char x[20][20],int y,int z,FILE* arch);
void imprimirMatText(char x[20][20]);
int main(){
    FILE* arch;
    arch=fopen("C:\\Users\\Asun\\Desktop\\programacio estructurada\\equipos.txt","r");
    int filas=20,columnas=20;
    char matriz[filas][columnas];
    cargarMatTextDeArch(matriz,filas,columnas,arch);
    imprimirMatText(matriz);
    fclose(arch);
    return 0;
}
void cargarMatTextDeArch(char x[20][20],int y,int z,FILE* arch){
    int f=0,c=0;
    char caracter;
    caracter=fgetc(arch);
    while(caracter!=-1){
        while(caracter!='\n'){
            x[f][c]=caracter;
            caracter=fgetc(arch);
            c++;
        }
        x[f][c]='\0';
        f++;
        c=0;
        caracter=fgetc(arch);
        if(caracter==-1){
            x[f][c]='\0';
        }
    }
}
void imprimirMatText(char x[20][20]){
    int f=0;
    while(x[f][0]!='\0'){
        printf("%s",x[f]);
        printf("\n");
        f++;
    }
}
