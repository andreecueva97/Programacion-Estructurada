#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void cargarMatTextDeArch(char x[20][25],int y,int z,FILE* arch);
void imprimirMatText(char x[20][25]);
void cargarMatNumDeArch(int x[5][8],int y,int z,FILE* arch);
void imprimirMatNum(int x[5][8],int y,int z);
void ordenarTabla(char u[20][25],int v[5][8],int w,int x,int y,int z);
void imprimirTabla(char x[20][25],char y[20][25],int z[5][8],int a);
int main(){
    FILE* arch1;
    FILE* arch2;
    FILE* arch3;
    arch1=fopen("cabeceras.txt","r");
    arch2=fopen("items.txt","r");
    arch3=fopen("datos.txt","r");
    int filas1=20,columnas1=25,filas2=5,columnas2=8,orden1=0,orden2=0;
    char matriz1[filas1][columnas1];
    char matriz2[filas1][columnas1];
    int matriz3[filas2][columnas2];
    cargarMatTextDeArch(matriz1,filas1,columnas1,arch1);
    cargarMatTextDeArch(matriz2,filas1,columnas1,arch2);
    cargarMatNumDeArch(matriz3,filas2,columnas2,arch3);
    imprimirMatText(matriz1);
    imprimirMatText(matriz2);
    imprimirMatNum(matriz3,filas2,columnas2);
    imprimirTabla(matriz1,matriz2,matriz3,columnas2);
    ordenarTabla(matriz2,matriz3,filas2,columnas2,orden1,orden2);
    imprimirTabla(matriz1,matriz2,matriz3,columnas2);
    fclose(arch1);
    fclose(arch2);
    fclose(arch3);
    return 0;
}
void cargarMatTextDeArch(char x[20][25],int y,int z,FILE* arch){
    int f=0,c=0;
    char caracter;
    caracter=fgetc(arch);
    while(caracter!=-1){
        while(caracter!='\n'){
            x[f][c]=caracter;
            caracter=fgetc(arch);
            c++;
        }
        x[f][c]='\0';
        f++;
        c=0;
        caracter=fgetc(arch);
        if(caracter==-1){
            x[f][c]='\0';
        }
    }
}
void imprimirMatText(char x[20][25]){
    int f=0;
    while(x[f][0]!='\0'){
        printf("%s",x[f]);
        printf("\n");
        f++;
    }
}
void cargarMatNumDeArch(int x[5][8],int y,int z,FILE* arch){
    int f=0,c=0,a,r;
    while(f!=y && r!=EOF){
        while(c!=z && r!=EOF){
            if(c==z-1){
                r=fscanf(arch,"%d\n",&a);
            }else{
                r=fscanf(arch,"%d,",&a);
            }
            x[f][c]=a;
            c++;
        }
        f++;
        c=0;
    }
}
void imprimirMatNum(int x[5][8],int y,int z){
    int f=0,c=0;
    while(f!=y){
        while(c!=z){
            if(x[f][c]>0 && c==z-1){
                printf("%+4d",x[f][c]);
            }else{
                printf("%4d",x[f][c]);
            }
            c++;
        }
        printf("\n");
        f++;
        c=0;
    }
}
void imprimirTabla(char x[20][25],char y[20][25],int z[5][8],int a){
    int f=0,c=0;
    while(x[f][0]!='\0'){
        if(f==0){
            printf("%-14s",x[f]);
        }else{
            printf("%s  ",x[f]);
        }
        f++;
    }
    f=0;
    printf("\n");
    printf("---------------------------------------------------");
    printf("\n");
    while(y[f][0]!='\0'){
        printf("%-13s",y[f]);
        while(c!=a){
            if(z[f][c]>0 && c==z-1){
                printf("%+4d",z[f][c]);
            }else{
                printf("%4d",z[f][c]);
            }
            c++;
        }
        printf("\n");
        c=0;
        f++;
    }
}
void ordenarTabla(char u[20][25],int v[5][8],int w,int x,int y,int z){
    int c=0,f1=0,f2=f1+1,aux;
    char auxMat[25];
    while(f1!=w){
        while(f2!=w){
            if(v[f1][y]>v[f2][y] && z==0){
                strcpy(auxMat,u[f1]);
                strcpy(u[f1],u[f2]);
                strcpy(u[f2],auxMat);
                while(c!=x){
                    aux=v[f1][c];
                    v[f1][c]=v[f2][c];
                    v[f2][c]=aux;
                    c++;
                }
                c=0;
            }
            if(v[f1][y]<v[f2][y] && z==1){
                strcpy(auxMat,u[f1]);
                strcpy(u[f1],u[f2]);
                strcpy(u[f2],auxMat);
                while(c!=x){
                    aux=v[f1][c];
                    v[f1][c]=v[f2][c];
                    v[f2][c]=aux;
                    c++;
                }
                c=0;
            }
            f2++;
        }
        f1++;
        f2=f1+1;
    }
}
