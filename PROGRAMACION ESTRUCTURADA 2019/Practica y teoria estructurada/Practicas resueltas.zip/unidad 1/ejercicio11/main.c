#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void cargarMatTextDeArch(char x[][25],FILE* arch);
void imprimirMatText(char x[][25]);
void ordenarTexto(char x[][25],int y);
int main(){
    FILE* arch;
    arch=fopen("C:\\Users\\Asun\\Desktop\\programacio estructurada\\equipos.txt","r");
    int filas=20,columnas=25;
    char matriz[filas][columnas];
    cargarMatTextDeArch(matriz,arch);
    imprimirMatText(matriz);
    ordenarTexto(matriz,columnas);
    imprimirMatText(matriz);
    fclose(arch);
    return 0;
}
void cargarMatTextDeArch(char x[][25],FILE* arch){
    int f=0,c=0;
    char caracter;
    caracter=fgetc(arch);
    while(caracter!=-1){
        while(caracter!='\n'){
            x[f][c]=caracter;
            caracter=fgetc(arch);
            c++;
        }
        x[f][c]='\0';
        f++;
        c=0;
        caracter=fgetc(arch);
    }
    x[f][c]='\0';
}
void imprimirMatText(char x[][25]){
    int f=0;
    while(x[f][0]!='\0'){
        printf("%s",x[f]);
        printf("\n");
        f++;
    }
}
void ordenarTexto(char x[][25],int y){
    int c=0,f1=0,f2=f1+1,ret;
    char aux[25];
    while(x[f1][0]!='\0'){
        while(x[f2][0]!='\0'){
            ret=strcmp(x[f1],x[f2]);
            if(ret>0){
                strcpy(aux,x[f1]);
                while(c!=y){
                    x[f1][c]=x[f2][c];
                    c++;
                }
                c=0;
                while(c!=y){
                    x[f2][c]=aux[c];
                    c++;
                }
                c=0;
            }
            f2++;
        }
        f1++;
        f2=f1+1;
    }
}
