#include <stdio.h>
#include <stdlib.h>
void cargarArr(int x,int y[],int z);
void imprimirArr(int x,int y[]);
void invertirArr(int x,int y[]);
void ordenarArr(int x,int y[]);
int main(){
    int control,num,tam1,tam2;
    control=0;
    printf("ingrese el tamanio del arreglo1:");
    scanf("%d",&tam1);
    int arr1[tam1];
    printf("\ningrese numeros:");
    while(num!=0){
        scanf("%d",&num);
        cargarArr(num,arr1,control);
        control++;
        if(control==tam1){
            num=0;
        }
    }
    while(control!=tam1){
        cargarArr(0,arr1,control);
        control++;
    }
    imprimirArr(tam1,arr1);
    invertirArr(tam1,arr1);
    control=0;
    num=1;
    printf("\ningrese el tamanio del arreglo2:");
    scanf("%d",&tam2);
    int arr2[tam2];
    while(num!=0){
        scanf("%d",&num);
        cargarArr(num,arr2,control);
        control++;
        if(control==tam2){
            num=0;
        }
    }
    while(control!=tam2){
        cargarArr(0,arr2,control);
        control++;
    }
    imprimirArr(tam2,arr2);
    ordenarArr(tam2,arr2);
    return 0;
}
void cargarArr(int x,int y[],int z){
    y[z]=x;
}
void imprimirArr(int x,int y[]){
    int control;
    control=0;
    while(control!=x){
        if(y[control]!=0){
            printf("%d ",y[control]);
        }
        control++;
    }
    printf("\n");
}
void invertirArr(int x,int y[]){
    int control1,control2,num1;
    control1=0;
    control2=x-1;
    while(control1!=x/2){
        num1=y[control1];
        y[control1]=y[control2];
        y[control2]=num1;
        control1++;
        control2--;
    }
    imprimirArr(x,y);
}
void ordenarArr(int x,int y[]){
    int i,j,aux;
    for(i=0;i<x-1;i++){
        for(j=i+1;j<x;j++){
            if(y[i]>y[j]){
                aux=y[i];
                y[i]=y[j];
                y[j]=aux;
            }
        }
    }
    imprimirArr(x,y);
}
