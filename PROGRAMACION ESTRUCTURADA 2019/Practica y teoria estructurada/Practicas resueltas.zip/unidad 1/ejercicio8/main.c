#include <stdio.h>
#include <stdlib.h>
void cargarMat(int x[3][3],int y,int z);
void imprimirMat(int x[3][3],int y,int z);
void transponer(int x[3][3],int y,int z);
int main(){
    int matriz[3][3];
    printf("ingrese numeros:");
    cargarMat(matriz,3,3);
    imprimirMat(matriz,3,3);
    transponer(matriz,3,3);
    imprimirMat(matriz,3,3);
    return 0;
}
void cargarMat(int x[3][3],int y,int z){
    int f=0,c=0,num;
    while(f!=y){
        while(c!=z){
            scanf("%d",&num);
            x[f][c]=num;
            c++;
        }
        f++;
        c=0;
    }
}
void imprimirMat(int x[3][3],int y,int z){
    int f=0,c=0;
    while(f!=y){
        while(c!=z){
            printf("%d ",x[f][c]);
            c++;
        }
        printf("\n");
        f++;
        c=0;
    }
}
void transponer(int x[3][3],int y,int z){
    int f=0,c=0,aux;
    while(f!=y){
        while(c!=z){
                if(f!=c && c<f){
                    aux=x[f][c];
                    x[f][c]=x[c][f];
                    x[c][f]=aux;
                }
            c++;
        }
        f++;
        c=0;
    }
}
