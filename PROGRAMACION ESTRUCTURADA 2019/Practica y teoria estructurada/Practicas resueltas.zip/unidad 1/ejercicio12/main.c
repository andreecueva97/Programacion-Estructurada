#include <stdio.h>
#include <stdlib.h>
void cargarMatNumDeArch(int y,int z,int x[y][z],FILE* arch);
void imprimirMatNum(int y,int z,int x[y][z]);
int main(){
    FILE* arch;
    arch=fopen("puntos.txt","r");
    int filas=5,columnas=8;
    int matriz[filas][columnas];
    cargarMatNumDeArch(filas,columnas,matriz,arch);
    imprimirMatNum(filas,columnas,matriz);
    fclose(arch);
    return 0;
}
void cargarMatNumDeArch(int y,int z,int x[y][z],FILE* arch){
    int f=0,c=0,a,r;
    while(f!=y && r!=EOF){
        while(c!=z && r!=EOF){
            if(c==z-1){
                r=fscanf(arch,"%d\n",&a);
            }else{
                r=fscanf(arch,"%d,",&a);
            }
            x[f][c]=a;
            c++;
        }
        f++;
        c=0;
    }
}
void imprimirMatNum(int y,int z,int x[y][z]){
    int f=0,c=0;
    while(f!=y){
        while(c!=z){
            if(x[f][c]>0 && c==z-1){
                printf("%+4d",x[f][c]);
            }else{
                printf("%4d",x[f][c]);
            }
            c++;
        }
        printf("\n");
        f++;
        c=0;
    }
}
