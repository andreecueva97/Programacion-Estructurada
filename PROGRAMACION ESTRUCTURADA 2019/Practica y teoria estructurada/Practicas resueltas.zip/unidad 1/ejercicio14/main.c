#include <stdio.h>
#include <stdlib.h>
void cargarMatNumDeArch(int y,int z,int x[y][z],FILE* arch);
void cargarArrNumDeArch(int y,int x[y],FILE* arch);
void imprimirMatNum(int y,int z,int x[y][z]);
void minAnual(int y,int z,int x[y][z]);
void maxAnual(int y,int z,int x[y][z]);
void promedios(int v,int y,int z,int x[y][z],int w[v]);
int main(){
    FILE* arch1;
    FILE* arch2;
    arch1=fopen("temperaturas.txt","r");
    arch2=fopen("diasMedidos.txt","r");
    int filas=31,columnas=12,tam=12;
    int matriz[filas][columnas];
    int arr[tam];
    cargarMatNumDeArch(filas,columnas,matriz,arch1);
    cargarArrNumDeArch(tam,arr,arch2);
    imprimirMatNum(filas,columnas,matriz);
    printf("\n");
    promedios(tam,filas,columnas,matriz,arr);
    minAnual(filas,columnas,matriz);
    maxAnual(filas,columnas,matriz);
    fclose(arch1);
    fclose(arch2);
    return 0;
}
void cargarMatNumDeArch(int y,int z,int x[y][z],FILE* arch){
    int f=0,c=0,a,r;
    while(c!=z && r!=EOF){
        while(f!=y && r!=EOF){
            if(f==y-1){
                r=fscanf(arch,"%d\n",&a);
            }else{
                r=fscanf(arch,"%d,",&a);
            }
            x[f][c]=a;
            f++;
        }
        c++;
        f=0;
    }
}
void imprimirMatNum(int y,int z,int x[y][z]){
    int f=0,c=0;
    while(f!=y){
        while(c!=z){
            if(x[f][c]==99){
                printf("    ");
            }else{
                printf("%4d",x[f][c]);
            }
            c++;
        }
        printf("\n");
        f++;
        c=0;
    }
}
void cargarArrNumDeArch(int y,int x[y],FILE* arch){
    int i=0,a,r;
    while(i!=y && r!=EOF){
        if(i==y-1){
            r=fscanf(arch,"%d\n",&a);
        }else{
            r=fscanf(arch,"%d,",&a);
        }
        x[i]=a;
        i++;
    }
}
void minAnual(int y,int z,int x[y][z]){
    int f=0,c=0,min=99;
    while(c!=z){
        while(f!=y){
            if(x[f][c]!=99 && x[f][c]<min){
                min=x[f][c];
            }
            f++;
        }
        c++;
        f=0;
    }
    printf("La temperatura minima anual es: %d",min);
    printf("\n");
}
void maxAnual(int y,int z,int x[y][z]){
    int f=0,c=0,max=-99;
    while(c!=z){
        while(f!=y){
            if(x[f][c]!=99 && x[f][c]>max){
                max=x[f][c];
            }
            f++;
        }
        c++;
        f=0;
    }
    printf("La temperatura maxima anual es: %d",max);
    printf("\n");
}
void promedios(int v,int y,int z,int x[y][z],int w[v]){
    int f=0,c=0,promedioMax=-99,promedioMin=99,promedioAnual=0,promedioMensual,sum1=0,sum2=0;
    printf("Promedios mes a mes");
    while(c!=z){
        while(f!=y){
            if(x[f][c]!=99){
                sum1+=x[f][c];
            }
            f++;
        }
        promedioMensual=sum1/w[c];
        printf("%4d",promedioMensual);
        if(promedioMensual>promedioMax){
            promedioMax=promedioMensual;
        }
        if(promedioMensual<promedioMin){
            promedioMin=promedioMensual;
        }
        sum2+=promedioMensual;
        c++;
        f=0;
        sum1=0;
    }
    promedioAnual=sum2/c;
    printf("\n");
    printf("Temperatura maxima promedio:%d",promedioMax);
    printf("\n");
    printf("Temperatura minima promedio:%d",promedioMin);
    printf("\n");
    printf("Temperatura promedio anual:%d",promedioAnual);
    printf("\n");
}
