#include <stdio.h>
#include <stdlib.h>
void cargarArrPNR(int x,int y[],int z);
void imprimirArr(int x,int y[]);
int estaEnArr(int x,int y[],int z);
int esPos(int x);
int main(){
    int control,num,tam,bool1,bool2;
    control=0;
    printf("ingrese el tamanio del arreglo:");
    scanf("%d",&tam);
    int arr[tam];
    printf("\ningrese numeros positivos:");
    while(num!=0){
        scanf("%d",&num);
        bool1=estaEnArr(tam,arr,num);
        bool2=esPos(num);
        if(bool1==0 && bool2==1){
            cargarArrPNR(num,arr,control);
            control++;
        }
        if(control==tam){
            num=0;
        }
    }
    while(control!=tam){
        cargarArrPNR(0,arr,control);
        control++;
    }
    imprimirArr(tam,arr);
    control=0;
    num=1;
    return 0;
}
void cargarArrPNR(int x,int y[],int z){
    y[z]=x;
}
void imprimirArr(int x,int y[]){
    int control;
    control=0;
    while(control!=x){
        if(y[control]!=0){
            printf("%d ",y[control]);
        }
        control++;
    }
    printf("\n");
}
int estaEnArr(int x,int y[],int z){
    int control;
    control=0;
    while(control!=x){
        if(z==y[control]){
            return 1;
        }
        control++;
    }
    return 0;
}
int esPos(int x){
    if(x>=0){
        return 1;
    }
    return 0;
}
