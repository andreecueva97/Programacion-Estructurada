#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>
typedef struct
{
char * txt;
unsigned int longitud;
}
t_texto;
void texto(int tam,char **arr);
void longitudYTexto(char **arr,unsigned int *longitud);
void frasesIndefinidas(t_texto **frases,int tam);
void ordenarStructDinamico(t_texto **frases);
void imprimirStructDinamico(t_texto *frases);
void imprimirStructDinamicoEnArch(t_texto *frases,FILE *arch);
int main()
{
    FILE *arch;
    arch=fopen("frases_con_longitud.txt","a");
    t_texto *frases=NULL;
    frasesIndefinidas(&(frases),2);
    printf("%s %d",(*(frases+1)).txt,(*(frases+1)).longitud);
    ordenarStructDinamico(&(frases));
    printf("\n%s %d",(*(frases+1)).txt,(*(frases+1)).longitud);
    imprimirStructDinamico(frases);
    imprimirStructDinamicoEnArch(frases,arch);
    free(frases);
    fclose(arch);
    return 0;
}
void texto(int tam,char **arr){
    *arr=malloc(tam);
    int i=0;
    char caracter;
    caracter=getche();
    while(caracter!='\r'){
        (*(*(arr)+i))=caracter;
        caracter=getche();
        i++;
        if(i==tam){
            *(arr)=realloc(*(arr),tam+1);
            tam++;
        }
    }
    (*(*(arr)+i))='\0';
}
void longitudYTexto(char **arr,unsigned int *longitud){
    texto(1,arr);
    int i;
    for(i=0;(*(*(arr)+i))!='\0';i++);
    /*while((*(*(arr)+i))!='\0'){     Este es otro metodo pero es mas eficaz el for
        i++;
    }*/
    *longitud=i;
}
void frasesIndefinidas(t_texto **frases,int tam){
    *(frases)=malloc(tam*sizeof(t_texto));
    int i=0,control;
    while(control!=0){
        (*(*(frases)+i)).txt=NULL;
        (*(*(frases)+i)).longitud=0;
        longitudYTexto(&((*(*(frases)+i)).txt),&((*(*(frases)+i)).longitud));
        printf("\n");
        control=(*(*(frases)+i)).longitud;
        if((*(*(frases)+i)).longitud==0){
            (*(*(frases)+i)).txt=NULL;
        }
        i++;
        if(i==tam){
            *(frases)=realloc(*(frases),(tam+1)*sizeof(t_texto));
            tam++;
        }
    }
}
void ordenarStructDinamico(t_texto **frases){
    int i=0,j=i+1,aux1;
    char *aux2;
    while(((*(*(frases)+i)).txt)!=NULL){
        while(((*(*(frases)+j)).txt)!=NULL){
            if(strcmp((*(*(frases)+i)).txt,(*(*(frases)+j)).txt)>0){
                aux1=(*(*(frases)+i)).longitud;
                (*(*(frases)+i)).longitud=(*(*(frases)+j)).longitud;
                (*(*(frases)+j)).longitud=aux1;
                aux2=(*(*(frases)+i)).txt;
                (*(*(frases)+i)).txt=(*(*(frases)+j)).txt;
                (*(*(frases)+j)).txt=aux2;
            }
            j++;
        }
        i++;
        j=i+1;
    }
}
void imprimirStructDinamico(t_texto *frases){
    int i=0;
    while(((*(frases+i)).txt)!=NULL){
        printf("\n%s",(*(frases+i)).txt);
        i++;
    }
}
void imprimirStructDinamicoEnArch(t_texto *frases,FILE *arch){
    int i=0;
    while(((*(frases+i)).txt)!=NULL){
        fprintf(arch,"%d,%s\n",(*(frases+i)).longitud,(*(frases+i)).txt);
        i++;
    }
}
