#include <stdio.h>
#include <stdlib.h>
typedef struct
{
int a, b;
}
t_dosint;
void intercambioDeValores(int *puntero1,int *puntero2);
void llamadoAIntercambioDeValores(int *puntero1,int *puntero2);
int main()
{
    t_dosint num;
    num.a=2;
    num.b=1;
    llamadoAIntercambioDeValores(&num.a,&num.b);
    printf("%d,%d",num.a,num.b);
    return 0;
}
void intercambioDeValores(int *puntero1,int *puntero2){
    int aux;
    aux=*puntero1;
    *puntero1=*puntero2;
    *puntero2=aux;
}
void llamadoAIntercambioDeValores(int *puntero1,int *puntero2){
    intercambioDeValores(puntero1,puntero2);
}
