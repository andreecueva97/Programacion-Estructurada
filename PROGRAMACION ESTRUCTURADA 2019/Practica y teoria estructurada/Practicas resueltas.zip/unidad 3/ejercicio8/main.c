#include <stdio.h>
#include <stdlib.h>
void textoDeArch(int tam,char **arr,FILE *arch);
int main()
{
    FILE *arch;
    arch=fopen("frases.txt","r");
    char *arr=NULL;
    textoDeArch(40,&arr,arch);
    printf("%s",arr);
    free(arr);
    fclose(arch);
    return 0;
}
void textoDeArch(int tam,char **arr,FILE *arch){
    *arr=malloc(tam);
    int i=0;
    char caracter;
    caracter=fgetc(arch);
    while(caracter!='\n' && caracter!=EOF){
        (*(*(arr)+i))=caracter;
        caracter=fgetc(arch);
        i++;
        if(i==tam){
            realloc(*(arr),tam+1);
            tam++;
        }
    }
    (*(*(arr)+i))='\0';
}
