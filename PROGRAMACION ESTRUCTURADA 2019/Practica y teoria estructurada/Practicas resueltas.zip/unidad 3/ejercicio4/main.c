#include <stdio.h>
#include <stdlib.h>
typedef struct
{
int numero, valor;
char palo;
}
t_carta;
void ordenDelTruco(t_carta *puntero);
int main()
{
    t_carta card[3];
    card[0].numero=1;
    card[0].palo='E';
    card[0].valor=14;
    card[1].numero=1;
    card[1].palo='B';
    card[1].valor=13;
    card[2].numero=4;
    card[2].palo='C';
    card[2].valor=1;
    t_carta *puntero=card;
    ordenDelTruco(puntero);
    printf("%d\n%d\n%d\n",card[0].numero,card[1].numero,card[2].numero);
    return 0;
}
void ordenDelTruco(t_carta *puntero){
    t_carta aux;
    int i=0,j=i+1;
    while(i!=2){
        while(j!=3){
            if((*(puntero+i)).valor>(*(puntero+j)).valor){
                aux=*(puntero+i);
                *(puntero+i)=*(puntero+j);
                *(puntero+j)=aux;
            }
            j++;
        }
        i++;
        j=i+1;
    }
}
