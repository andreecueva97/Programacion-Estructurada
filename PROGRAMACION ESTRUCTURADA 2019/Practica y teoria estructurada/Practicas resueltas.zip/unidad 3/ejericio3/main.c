#include <stdio.h>
#include <stdlib.h>
void redondeoExterno(double *puntero);
int main()
{
    double a=9.51;
    double *puntero=&a;
    redondeoExterno(puntero);
    printf("%.0lf",a);
    return 0;
}
void redondeoExterno(double *puntero){
    int a=*puntero;
    if((*puntero-a)>=0.50){
        *puntero=a+1;
    }else{
        *puntero=a;
    }
}
