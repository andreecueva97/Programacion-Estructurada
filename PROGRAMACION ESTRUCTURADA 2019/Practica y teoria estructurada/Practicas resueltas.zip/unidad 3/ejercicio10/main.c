#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
typedef struct
{
char * txt;
unsigned int longitud;
}
t_texto;
void texto(int tam,char **arr);
void longitudYTexto(char **arr,unsigned int *longitud);
int main()
{
    FILE *arch;
    arch=fopen("frases_con_longitud.txt","a");
    t_texto t;
    t.txt=NULL,t.longitud=0;
    longitudYTexto(&t.txt,&t.longitud);
    fprintf(arch,"%d,%s\n",t.longitud,t.txt);
    free(t.txt);
    fclose(arch);
    return 0;
}
void texto(int tam,char **arr){
    *arr=malloc(tam);
    int i=0;
    char caracter;
    caracter=getche();
    while(caracter!='\r'){
        (*(*(arr)+i))=caracter;
        caracter=getche();
        i++;
        if(i==tam){
            realloc(*(arr),tam+1);
            tam++;
        }
    }
    (*(*(arr)+i))='\0';
}
void longitudYTexto(char **arr,unsigned int *longitud){
    texto(9,arr);
    int i;
    for(i=0;(*(*(arr)+i))!='\0';i++);
    /*while((*(*(arr)+i))!='\0'){     Este es otro metodo pero es mas eficiente el for
        i++;
    }*/
    *longitud=i;
}
