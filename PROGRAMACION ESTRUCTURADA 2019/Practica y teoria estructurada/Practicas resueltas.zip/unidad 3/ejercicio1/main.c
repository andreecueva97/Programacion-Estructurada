#include <stdio.h>
#include <stdlib.h>
void intercambioDeValores(int *puntero1,int *puntero2);
int main()
{
    int a=12,b=15;
    //int *puntero1=&a,*puntero2=&b;
    printf("%d %d\n",a,b);
    intercambioDeValores(&a,&b);
    printf("%d %d\n",a,b);
    return 0;
}
void intercambioDeValores(int *puntero1,int *puntero2){
    int aux;
    aux=*puntero1;
    *puntero1=*puntero2;
    *puntero2=aux;
}
