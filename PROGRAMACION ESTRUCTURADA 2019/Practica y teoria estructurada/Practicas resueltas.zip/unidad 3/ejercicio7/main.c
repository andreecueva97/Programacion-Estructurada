#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
void texto(int tam,char **arr);
int main()
{
    FILE *arch;
    arch=fopen("frases.txt","a");
    char *arr=NULL;
    texto(1,&arr);
    fprintf(arch,"%s\n",arr);
    free(arr);
    fclose(arch);
    return 0;
}
void texto(int tam,char **arr){
    *arr=malloc(tam*sizeof(char));
    int i=0;
    char caracter;
    caracter=getche();
    while(caracter!='\r'){
        (*(*(arr)+i))=caracter;
        caracter=getche();
        i++;
        if(i==tam){
            *arr=realloc(*(arr),(tam+1)*sizeof(char)); //OR realloc(arr,(tam+1)*sizeof(char));
            tam++;
        }
    }
    (*(*(arr)+i))='\0';
}
