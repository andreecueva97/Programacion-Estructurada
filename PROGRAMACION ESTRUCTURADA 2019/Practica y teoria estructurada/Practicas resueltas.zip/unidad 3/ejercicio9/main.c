#include <stdio.h>
#include <stdlib.h>
void textoDeArch(int tam,char **arr,FILE *arch);
char *subcadena(char *p, unsigned int i, unsigned int n);
int main()
{
    FILE *arch;
    arch=fopen("frases.txt","r");
    char *arr1=NULL,*arr2=NULL;
    textoDeArch(40,&arr1,arch);
    printf("%s\n",arr1);
    arr2=subcadena(arr1,8,5);
    printf("%s\n",arr2);
    free(arr1);
    fclose(arch);
    return 0;
}
void textoDeArch(int tam,char **arr,FILE *arch){
    *arr=malloc(tam);
    int i=0;
    char caracter;
    caracter=fgetc(arch);
    while(caracter!='\n' && caracter!=EOF){
        (*(*(arr)+i))=caracter;
        caracter=fgetc(arch);
        i++;
        if(i==tam){
            realloc(*(arr),tam+1);
            tam++;
        }
    }
    (*(*(arr)+i))='\0';
}
char *subcadena(char *p, unsigned int i, unsigned int n){
    if(p==NULL){
        return NULL;
    }
    int contador;
    for(contador=0;*(p+contador)!='\0';contador++);
    if(i>contador){
        return NULL;
    }else{
        char *arr=NULL;
        arr=malloc(n+1);
        contador=0;
        while(contador!=n && (*(arr+contador))!='\0'){
            (*(arr+contador))=(*(p+i+contador));
            contador++;
        }
        (*(arr+contador))='\0';
        return arr;
    }
}
