#include <stdio.h>
#include <stdlib.h>
int direccionDeMemoriaDeUnaPosicion(int a[5],int pos);
int main()
{
    int *dir;
    int a[5]={3,5,6,8,9};
    printf("%d\n%p\n",&a[2],&a[2]);
    dir=direccionDeMemoriaDeUnaPosicion(a,2);
    printf("%d\n%p\n",dir,dir);
    return 0;
}
int direccionDeMemoriaDeUnaPosicion(int a[5],int pos){
    return &a[pos];
}
