#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int n,o,p,q,r,s,t,u,v,w,x,y,z;
    char p1[100],p2[200],p3[300],p4[400],p5[500];
    double a,b,c,d,e,f,g,h,i,j,k,l,m;
}
t_varios;
void intercambioStruct(t_varios *puntero1,t_varios *puntero2);
int main()
{
    t_varios test1,test2;
    test1.n=1;
    test2.n=2;
    t_varios *puntero1=&test1,*puntero2=&test2;
    intercambioStruct(puntero1,puntero2);
    printf("%d\n%d",test1.n,test2.n);
    return 0;
}
void intercambioStruct(t_varios *puntero1,t_varios *puntero2){
    t_varios aux;
    aux=*(puntero1);
    *(puntero1)=*(puntero2);
    *(puntero2)=aux;
}
