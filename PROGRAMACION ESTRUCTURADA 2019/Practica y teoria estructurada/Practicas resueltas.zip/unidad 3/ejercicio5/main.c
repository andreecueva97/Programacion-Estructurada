#include <stdio.h>
#include <stdlib.h>
typedef struct
{
    int a,b,c,d;
}
t_cuatro;
void ordenarStruct(t_cuatro *puntero);
int main()
{
    t_cuatro x;
    x.a=4;
    x.b=9;
    x.c=18;
    x.d=1;
    t_cuatro *puntero=&x;
    ordenarStruct(puntero);
    printf("%d\n%d\n%d\n%d",x.a,x.b,x.c,x.d);
    return 0;
}
void ordenarStruct(t_cuatro *puntero){
    int aux;
    if((*(puntero)).a>(*(puntero)).b){
        aux=(*(puntero)).a;
        (*(puntero)).a=(*(puntero)).b;
        (*(puntero)).b=aux;
    }
    if((*(puntero)).a>(*(puntero)).c){
        aux=(*(puntero)).a;
        (*(puntero)).a=(*(puntero)).c;
        (*(puntero)).c=aux;
    }
    if((*(puntero)).a>(*(puntero)).d){
        aux=(*(puntero)).a;
        (*(puntero)).a=(*(puntero)).d;
        (*(puntero)).d=aux;
    }
    if((*(puntero)).b>(*(puntero)).c){
        aux=(*(puntero)).b;
        (*(puntero)).b=(*(puntero)).c;
        (*(puntero)).c=aux;
    }
    if((*(puntero)).b>(*(puntero)).d){
        aux=(*(puntero)).b;
        (*(puntero)).b=(*(puntero)).d;
        (*(puntero)).d=aux;
    }
    if((*(puntero)).c>(*(puntero)).d){
        aux=(*(puntero)).c;
        (*(puntero)).c=(*(puntero)).d;
        (*(puntero)).d=aux;
    }
}
