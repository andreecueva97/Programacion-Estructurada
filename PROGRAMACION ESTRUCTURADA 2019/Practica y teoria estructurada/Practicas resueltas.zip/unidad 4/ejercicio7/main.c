#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
typedef struct
{
char * txt;
unsigned int longitud;
}
t_texto;
void texto(int tam,char **arr);
void longitudYTexto(char **arr,unsigned int *longitud);
int cantidadDeVocalesRecursivo(char *arr);
int main()
{
    int vocales;
    t_texto t;
    t.txt=NULL,t.longitud=0;
    longitudYTexto(&t.txt,&t.longitud);
    printf("\n%d,%s\n",t.longitud,t.txt);
    vocales=cantidadDeVocalesRecursivo(t.txt);
    printf("%d",vocales);
    free(t.txt);
    return 0;
}
void texto(int tam,char **arr){
    *arr=malloc(tam);
    int i=0;
    char caracter;
    caracter=getche();
    while(caracter!='\r'){
        (*(*(arr)+i))=caracter;
        caracter=getche();
        i++;
        if(i==tam){
            realloc(*(arr),tam+1);
            tam++;
        }
    }
    (*(*(arr)+i))='\0';
}
void longitudYTexto(char **arr,unsigned int *longitud){
    texto(9,arr);
    int i=0,contador=0;
    while((*(*(arr)+i))!='\0'){
        contador++;
        i++;
    }
    *longitud=contador;
}
int cantidadDeVocalesRecursivo(char *arr){
    int vocales=0;
    if(*(arr)!='\0'){
        vocales+=cantidadDeVocalesRecursivo(arr+1);
    }
    if((*(arr))=='a' || (*(arr))=='e' || (*(arr))=='i' || (*(arr))=='o' || (*(arr))=='u'){
        vocales+=1;
    }
    return vocales;
}
