#include <stdio.h>
#include <stdlib.h>
int restoRecursivo(int a,int b);
int main()
{
    int resto;
    resto=restoRecursivo(15,3);
    printf("%d",resto);
    return 0;
}
int restoRecursivo(int a,int b){
    int resto;
    if(a>=b){
        resto=restoRecursivo(a-b,b);
    }else{
        resto=a;
    }
    return resto;
}
