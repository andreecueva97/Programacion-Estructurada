#include <stdio.h>
#include <stdlib.h>
int cocienteRecursivo(int a,int b);
int main()
{
    int cociente;
    cociente=cocienteRecursivo(15,3);
    printf("%d",cociente);
    return 0;
}
int cocienteRecursivo(int a,int b){
    int cociente=0;
    if(a>=b){
        cociente=1;
        cociente=cociente+cocienteRecursivo(a-b,b);
    }
    return cociente;
}
