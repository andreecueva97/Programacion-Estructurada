#include <stdio.h>
#include <stdlib.h>
void invertir(int *arr, unsigned int valores);
int main()
{
    int *arr,num,i=0,j=0;
    arr=malloc(40);
    scanf("%d",&num);
    while(num!=0){
        *(arr+i)=num;
        scanf("%d",&num);
        i++;
    }
    invertir(arr,i);
    while(j!=i){
        printf("%d,",*(arr+j));
        j++;
    }
    free(arr);
    return 0;
}
void invertir(int *arr, unsigned int valores){
    int aux,control;
    if((valores-1)>0 && valores!=0){          //la segunda condicion fue agregada porque es un unsigned int
        aux=*(arr);
        control=*(arr+(valores-1));
        *(arr)=*(arr+(valores-1));
        *(arr+(valores-1))=aux;
        invertir(arr+1,valores-2);
    }
}
