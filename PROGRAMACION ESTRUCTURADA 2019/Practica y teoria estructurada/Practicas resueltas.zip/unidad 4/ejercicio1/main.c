#include <stdio.h>
#include <stdlib.h>
int productoRecursivo(int a,int b);
int main()
{
    int producto;
    producto=productoRecursivo(100,10);
    printf("%d",producto);
    return 0;
}
int productoRecursivo(int a,int b){
    if(b>1){
        a=a+productoRecursivo(a,b-1);
    }
    return a;
}
