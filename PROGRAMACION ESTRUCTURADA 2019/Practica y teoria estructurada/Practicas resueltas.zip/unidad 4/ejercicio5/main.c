#include <stdio.h>
#include <stdlib.h>
int maximoRecursivo(int *arr);
int* direccionDelMaximoRecursivo(int *arr);
int minimoRecursivo(int *arr);
int* direccionDelMinimoRecursivo(int *arr);
int main()
{
    int *arr,num,i=0,max,min,*puntero;
    arr=malloc(40);
    while(num!=0){
        scanf("%d",&num);
        *(arr+i)=num;
        i++;
    }
    max=maximoRecursivo(arr);
    printf("%d\n",max);
    puntero=direccionDelMaximoRecursivo(arr);
    printf("%d\n",*(puntero));
    min=minimoRecursivo(arr);
    printf("%d\n",min);
    puntero=direccionDelMinimoRecursivo(arr);
    printf("%d\n",*(puntero));
    free(arr);
    return 0;
}
int maximoRecursivo(int *arr){
    int max1=*(arr),max2;
    if((*(arr+1))!=0){
        max2=maximoRecursivo(arr+1);
        if(max2>max1){
            max1=max2;
        }
    }
    return max1;
}
int* direccionDelMaximoRecursivo(int *arr){
    int *max1,*max2;
    max1=arr;
    if((*(arr+1))!=0){
        max2=direccionDelMaximoRecursivo(arr+1);
        if((*(max2))>(*(max1))){
            max1=max2;
        }
    }
    return max1;
}
int minimoRecursivo(int *arr){
    int min1=*(arr),min2;
    if((*(arr+1))!=0){
        min2=minimoRecursivo(arr+1);
        if(min2<min1){
            min1=min2;
        }
    }
    return min1;
}
int* direccionDelMinimoRecursivo(int *arr){
    int *min1,*min2;
    min1=arr;
    if((*(arr+1))!=0){
        min2=direccionDelMinimoRecursivo(arr+1);
        if((*(min2))<(*(min1))){
            min1=min2;
        }
    }
    return min1;
}
