#include <stdio.h>
#include <stdlib.h>
int* direccionDelMinimoRecursivo(int *arr);
void ordenarCrecientementeRecursivo(int *arr);
int main()
{
    int *arr,num,i=0,*puntero;
    arr=malloc(sizeof(int)*(i+1));
    while(num!=0){
        scanf("%d",&num);
        *(arr+i)=num;
        i++;
        arr=realloc(arr,sizeof(int)*(i+1));
    }
    puntero=direccionDelMinimoRecursivo(arr);
    printf("%d\n",*(puntero));
    ordenarCrecientementeRecursivo(arr);
    i=0;
    while(*(arr+i)!=0){
        printf("%d,",*(arr+i));
        i++;
    }
    free(arr);
    return 0;
}
int* direccionDelMinimoRecursivo(int *arr){
    int *min1,*min2;
    min1=arr;
    if((*(arr+1))!=0){
        min2=direccionDelMinimoRecursivo(arr+1);
        if((*(min2))<(*(min1))){
            min1=min2;
        }
    }
    return min1;
}
void ordenarCrecientementeRecursivo(int *arr){
    int aux,*min;
    if((*(arr))!=0){
        min=direccionDelMinimoRecursivo(arr);
        aux=*(arr);
        *(arr)=*(min);
        *(min)=aux;
        ordenarCrecientementeRecursivo(arr+1);
    }
}
