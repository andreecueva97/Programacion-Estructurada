#include <stdio.h>
#include <stdlib.h>
#define N 5
#define M 5
typedef struct{
    int fila,columna;
} s_pos_mat;

void reconstruir_matriz(int *backup,char matriz[N][M]);
s_pos_mat* posicionesVacias(char matriz[N][M]);
int sumaImpar(int n,int m);
int main()
{
    int backup[2]={4391169,0};
    char matriz[N][M];
    int i,j;
    for(i=0;i<N;i++){
        for(j=0;j<M;j++){
            matriz[i][j]='-';
        }
    }
    reconstruir_matriz(backup,matriz);
    s_pos_mat* arr=posicionesVacias(matriz);
    i=0;
    while(((*(arr+i)).fila)!=-1 && ((*(arr+i)).columna)!=-1){
        printf("fila:%d, columna:%d\n",(*(arr+i)).fila,(*(arr+i)).columna);
        i++;
    }
    free(arr);
    int suma=sumaImpar(2,7);
    printf("%d",suma);
    return 0;
}
s_pos_mat* posicionesVacias(char matriz[N][M]){
    s_pos_mat* arr=NULL;
    arr=malloc(sizeof(s_pos_mat));
    int i,j,h=0;
    for(i=0;i<N;i++){
        for(j=0;j<M;j++){
            if(matriz[i][j]=='-'){
                (*(arr+h)).fila=i;
                (*(arr+h)).columna=j;
                h++;
                arr=realloc(arr,sizeof(s_pos_mat)*(h+1));
            }
        }
    }
    (*(arr+h)).fila=-1;
    (*(arr+h)).columna=-1;
    return arr;
}
void reconstruir_matriz(int *backup,char matriz[N][M]){
    int i,fila,columna;
    char caracter;
    for(i=0;*(backup+i)!=0;i++){
        columna=*(backup+i)&255;
        fila=(*(backup+i)>>8)&255;
        caracter=(*(backup+i)>>16)&255;
        matriz[fila][columna]=caracter;
        printf("%d,%d,%c",columna,fila,caracter);
    }
}
int sumaImpar(int n,int m){
    if(n<=m){
        if((n%2)!=0){
            return n+sumaImpar(n+1,m);
        }else{
            return 0+sumaImpar(n+1,m);
        }
    }else{
        return 0;
    }
}
