#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define T 4
typedef struct Persona{

    int estatura;
    char* apellido;

}Persona_T;
struct s_ciudad{
    int cod;
    char *nombre;
    unsigned char cod_pai;   //codigo pais
};
typedef struct s_ciudad t_ciudad;
t_ciudad* filtrar(t_ciudad arr[T],char cod_pai);
int main()
{
    t_ciudad arr[T];
    t_ciudad* resul = NULL;
    int i;

    arr[0].cod = 1;
    arr[0].cod_pai = 'c';
    arr[0].nombre = "Buenos Aires";

    arr[2].cod = 3;
    arr[2].cod_pai = 'b';
    arr[2].nombre = "Sao Pablo";

    arr[1].cod = 2;
    arr[1].cod_pai = 'c';
    arr[1].nombre = "Cordoba";

    arr[3].cod = 0;
    arr[3].cod_pai = 'c';
    arr[3].nombre = "Bueqweqweos Aires";

    resul = filtrar(arr,'c');

    for(i=0; resul[i].cod != 0; i++)
    {
        printf("%c, %d, %s \n",resul[i].cod_pai,resul[i].cod,resul[i].nombre);
    }
    return 0;
}
t_ciudad* filtrar(t_ciudad arr[T],char cod_pai){
    t_ciudad *dynArr=NULL;
    dynArr=malloc(sizeof(t_ciudad));
    int i,j=0;
    for(i=0;arr[i].cod!=0 && i<T;i++){
        if(arr[i].cod_pai==cod_pai){
            (*(dynArr+j))=arr[i];
            j++;
            dynArr=realloc(dynArr,sizeof(t_ciudad)*(j+1));
        }
    }
    (*(dynArr+j)).cod=0;
    t_ciudad aux;
    for(i=0;(*(dynArr+i)).cod!=0;i++){
        for(j=i+1;(*(dynArr+j)).cod!=0;j++){
            if(strcmp((*(dynArr+i)).nombre,(*(dynArr+j)).nombre)>0){
                aux=(*(dynArr+i));
                (*(dynArr+i))=(*(dynArr+j));
                (*(dynArr+j))=aux;
            }
        }
    }
    return dynArr;
}
/*int valor(int x){
    int MASK1 = 32640;
    if ((x & MASK1)!=0){
        return -1;
    }
    return 1;
}
Persona_T* cargar_personas(int * Estaturas, char** Apellidos){
    int cont = 0, cont_per = 0;
    Persona_T* Personas = NULL;
    Personas=(Persona_T*)malloc(sizeof(Persona_T)*(cont_per+1));
    printf("\nMalloque");
    while(Estaturas[cont]!=0 ){
            printf("\nEntre al while | cont: %d | cont_per: %d ", cont, cont_per);
            if(valor(Estaturas[cont])==1){
                (*(Personas+cont_per)).estatura = *(Estaturas+cont);
                printf("\nPor hacer copy %s", *(Apellidos+cont));
                (*(Personas+cont_per)).apellido = *(Apellidos+cont);
                printf("\nLo logreee copy");
                cont_per++;
                Personas=realloc(Personas, (sizeof(Persona_T)*(cont_per+1)));
            }
            cont++;
    }
    return Personas;
}
int main(){
    int i;
    int * Estaturas = (int*)malloc(sizeof(int)*6);
    Persona_T* Personas = NULL;
    char arr0[100]="Gaspar";
    char arr1[100]="Pablo";
    char arr2[100]="Joaquin";
    char arr3[100]="Pepe";
    char arr4[100]="juan";
    *(Estaturas+0) = 1;
    *(Estaturas+1) = 2;
    *(Estaturas+2) = 3;
    *(Estaturas+3) = 4;
    *(Estaturas+4) = 5;
    *(Estaturas+5) = 0;
    char** Apellidos = NULL;
    Apellidos=malloc(sizeof(char*)*6);
    (*(Apellidos+0)) = arr0;
    (*(Apellidos+1)) = arr1;
    (*(Apellidos+2)) = arr2;
    (*(Apellidos+3)) = arr3;
    (*(Apellidos+4)) = arr4;
    Personas=cargar_personas(Estaturas, Apellidos);
    for(i=0;i<5;i++){
        printf("\n%s:%d",(*(Personas+i)).apellido,(*(Personas+i)).estatura);
    }
    return 0;
}*/ /*
int contar(char* str, char c){
    char a=c;
    if(c>=97 && c<=122){
        a=a-32;
    }
    if(c>=65 && c<=90){
        a=a+32;
    }
    if(*(str)!='\0'){
        if(*(str)==c || *(str)==a){
            return 1+contar(str+1,c);
        }else{
            return 0+contar(str+1,c);
        }
    }else{
        return 0;
    }
}
int main(){
    int c;
    char *arreglo=NULL;
    arreglo=malloc(50);
    arreglo="universidad catoliCa";
    c=contar(arreglo,'c');
    printf("%d",c);
    return 0;
}*/
