#include <stdio.h>
#include <stdlib.h>
struct s_nodo
{
int valor;
struct s_nodo* sig;
};
typedef struct s_nodo* t_nodo;
struct s_cola
{
t_nodo frente;
t_nodo final;
};
typedef struct s_cola t_cola;
struct s_nodo_bin
{
int valor;
struct s_nodo_bin* izq;
struct s_nodo_bin* der;
};
typedef struct s_nodo_bin* t_nodo_bin;
void queue(t_cola* cola, int valor);
int dequeue(t_cola* cola);
void agregar(t_nodo_bin* arbol, int valor);
void postorderEliminar(t_nodo_bin* arbol);
void BuscarYEliminar(t_nodo_bin* arbol,int valor);
int esta(t_nodo_bin arbol, int valor);
void preorder(t_nodo_bin arbol);
void inorder(t_nodo_bin arbol);
void postorder(t_nodo_bin arbol);
void por_niveles(t_nodo_bin arbol);
void imprimirUnNivel(t_nodo_bin arbol,int nivel);
int alturaDelArbol(t_nodo_bin arbol);
void por_nivelesSinColas(t_nodo_bin arbol);
int main()
{
    int val;
    t_nodo_bin arbol=NULL;
    printf("Ingrese valores, con 0 finaliza: ");
    scanf("%d", &val);
    while(val!=0){
        agregar(&arbol,val);
        printf("Ingrese valores, con 0 finaliza: ");
        scanf("%d", &val);
        while(esta(arbol,val)==1){
            printf("Error.El valor ya fue Ingresado.Ingrese valores, con 0 finaliza: ");
            scanf("%d", &val);
        }
    }
    printf("Pre-order:");
    preorder(arbol);
    printf("\nIn-order:");
    inorder(arbol);
    printf("\nPost-order:");
    postorder(arbol);
    printf("\nPor-niveles:");
    por_nivelesSinColas(arbol);
    BuscarYEliminar(&arbol,5);
    printf("\nIn-order:");
    inorder(arbol);
    return 0;
}
void queue(t_cola* cola, int valor){
    t_nodo aux = (t_nodo) malloc(sizeof(struct s_nodo));
    (*aux).valor = valor;
    (*aux).sig = NULL;
    if ((*cola).frente == NULL && (*cola).final == NULL){
        (*cola).frente = aux;
        (*cola).final = aux;
    }
    else{
        (*(*cola).final).sig = aux;         //esto es igual a cola->final->sig =aux
        (*cola).final = aux;
    }
}
int dequeue(t_cola* cola){
    int valor;
    t_nodo aux = (*cola).frente;
    (*cola).frente = (*(*cola).frente).sig;
    valor = (*aux).valor;
    free(aux);
    if ((*cola).frente == NULL){
        (*cola).final = NULL;
    }
    return valor;
}
void agregar(t_nodo_bin* arbol, int valor){
    if (*arbol == NULL){
        *arbol = (t_nodo_bin)malloc(sizeof(struct s_nodo_bin));
        (*(*arbol)).valor = valor;
        (*(*arbol)).izq = NULL;
        (*(*arbol)).der = NULL;
    }else{
    if (valor < (*(*arbol)).valor)
        agregar(& (*(*arbol)).izq, valor);
    else
        agregar(& (*(*arbol)).der, valor);
    }
}
void postorderEliminar(t_nodo_bin* arbol){
    if (*arbol != NULL){
        postorderEliminar(&(*arbol)->izq);
        postorderEliminar(&(*arbol)->der);
        free(*arbol);
        *arbol=NULL;
    }
}
void BuscarYEliminar(t_nodo_bin* arbol,int valor){
    if(*arbol==NULL){
        printf("Error,arbol vacio o valor no encontrado");
    }else{
        if(valor==(**arbol).valor){
            postorderEliminar(arbol);
        }else{
            if (valor < (**arbol).valor)
                BuscarYEliminar(&(**arbol).izq, valor);
            else
                BuscarYEliminar(&(**arbol).der, valor);
        }
    }
}
int esta(t_nodo_bin arbol, int valor){
    if (arbol == NULL)
        return 0;
    else{
        if (valor == (*arbol).valor)
            return 1;
        else{
            if (valor < (*arbol).valor)
                return esta((*arbol).izq, valor);
            else
                return esta((*arbol).der, valor);
        }
    }
}
void preorder(t_nodo_bin arbol){
    if (arbol != NULL){
        printf("%d - ", (*arbol).valor);
        preorder((*arbol).izq);
        preorder((*arbol).der);
    }
}
void inorder(t_nodo_bin arbol){
    if (arbol != NULL){
        inorder((*arbol).izq);
        printf("%d - ", (*arbol).valor);
        inorder((*arbol).der);
    }
}
void postorder(t_nodo_bin arbol){
    if (arbol != NULL){
        postorder((*arbol).izq);
        postorder((*arbol).der);
        printf("%d - ", (*arbol).valor);
    }
}
/*void por_niveles(t_nodo_bin arbol){
    t_cola cola = {NULL, NULL};
    t_nodo_bin nodo_aux = NULL;
    queue(&cola, arbol);
    while (cola.frente != NULL){
        nodo_aux = dequeue(&cola);
        if (nodo_aux->izq != NULL)
            queue(&cola, nodo_aux->izq);
        if (nodo_aux->der != NULL)
            queue(&cola, nodo_aux->der);
        printf("%d -", nodo_aux->valor);
    }
}*/
void imprimirUnNivel(t_nodo_bin arbol,int nivel){
    if(arbol!=NULL){
        if(nivel==1)
            printf("%d-",(*arbol).valor);
        else{
            imprimirUnNivel((*arbol).izq,nivel-1);
            imprimirUnNivel((*arbol).der,nivel-1);
        }
    }
}
int alturaDelArbol(t_nodo_bin arbol){
    if(arbol==NULL)
        return 0;
    else{
        int alturaIzq,alturaDer;
        alturaIzq=alturaDelArbol((*arbol).izq);
        alturaDer=alturaDelArbol((*arbol).der);
        if(alturaIzq>alturaDer)
            return (alturaIzq+1);
        else
            return (alturaDer+1);
    }
}
void por_nivelesSinColas(t_nodo_bin arbol){
    int altura=alturaDelArbol(arbol);
    int i;
    for(i=1;i<=altura;i++)
        imprimirUnNivel(arbol,i);
}
