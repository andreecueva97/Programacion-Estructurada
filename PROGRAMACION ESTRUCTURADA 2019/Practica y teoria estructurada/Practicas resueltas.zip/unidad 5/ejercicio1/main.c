#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
struct s_nodo
{
int valor;
struct s_nodo* sig;
};
typedef struct s_nodo* t_nodo;
void agregar(t_nodo* lista, int valor);
void agregarYImprimirNormalmente(t_nodo* lista, int valor);
void agregarYImprimirInversamente(t_nodo* lista, int valor);
void imprimirListaNormalmente(t_nodo lista);
void imprimirListaInversamente(t_nodo lista);
void liberarLista(t_nodo* lista);
int main()
{
    t_nodo lista=NULL;
    agregarYImprimirNormalmente(&lista,1);
    printf("\n");
    agregarYImprimirNormalmente(&lista,2);
    printf("\n");
    agregarYImprimirNormalmente(&lista,3);
    printf("\n");
    agregarYImprimirNormalmente(&lista,4);
    printf("\n");
    imprimirListaInversamente(lista);
    printf("\n");
    imprimirListaNormalmente(lista);
    liberarLista(&lista);
    printf("\n");
    agregarYImprimirNormalmente(&lista,4);
    printf("\n");
    imprimirListaInversamente(lista);
    return 0;
}
void agregar(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregar(&((**lista).sig),valor);
    }
}
void agregarYImprimirNormalmente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
        printf("%d",((**lista).valor));
    }else{
        printf("%d",((**lista).valor));
        agregarYImprimirNormalmente(&((**lista).sig),valor);
    }
}
void agregarYImprimirInversamente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregarYImprimirInversamente(&((**lista).sig),valor);
    }
    printf("%d",((**lista).valor));
}
void imprimirListaInversamente(t_nodo lista){
    if((*lista).sig!=NULL){
        imprimirListaInversamente((*lista).sig);
    }
    printf("%d",(*lista).valor);
}
void imprimirListaNormalmente(t_nodo lista){
    if(lista!=NULL){
        printf("%d",(*lista).valor);
        imprimirListaNormalmente((*lista).sig);
    }
}
void liberarLista(t_nodo* lista){
    if(*lista!=NULL){
        liberarLista(&(**lista).sig);
        free(*lista);
        *lista=NULL;
    }
}
