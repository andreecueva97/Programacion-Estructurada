#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE* arch;
    int test=0,test2=10;
    char c='c';
    arch=fopen("test.dat","w+b");
    fwrite(&c,1,1,arch);
    fwrite(&test2,4,1,arch);
    rewind(arch);
    fread(&c,1,1,arch);
    fread(&test,4,1,arch);
    printf("%d",test);
    return 0;
}
