// tests
#include <stdio.h>
#include <stdlib.h>
struct s_test{
    int id;
    char nombre[50];
    int edad;
};
typedef struct s_test t_test;
int main()
{
    FILE* arch;
    arch=fopen("test.txt","rb");
    t_test arr[5];
    fread((arr+0),sizeof(t_test),1,arch);
    fread((arr+1),sizeof(t_test),1,arch);
    fread((arr+2),sizeof(t_test),1,arch);
    printf("%d,%s,%d",arr[0].id,arr[0].nombre,arr[0].edad);
    return 0;
}
