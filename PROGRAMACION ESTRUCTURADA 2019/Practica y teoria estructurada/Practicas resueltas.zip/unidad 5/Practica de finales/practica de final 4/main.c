#include <stdio.h>
#include <stdlib.h>
//Final de febrero 2011
//Ejercicio 1 me lo salteo

//Ejercicio 2.1
/*int main()
{
    int a=9, b=13, c=-3, d=8;
    int *bb, **cc;
    bb=&a;
    cc= &bb;
    (*bb)++;
    a= 5;
    **cc = **cc + 4; //se le suma a a 4
    cc = &d;
    printf("%d", *bb);// se imprime 9
}*/

//Ejercicio2.2
/*char x (char a)
{
    if (a<='w')
        printf("%c", x(a+1)); //se usa recursivamente hasta llegar a 'x'
    return 'w';
}
void main()
{ printf("%c",x('u')); //imprime wwww
}*/

//Ejercicio2.3
/*int main(){
    char *b = "3456789";
    char * p = b; //copia b
    p += 5; //le queda el string "89"
    printf( "%s%s", p,b ); // se imprime "893456789"
}*/

//Ejercicio2.4
int main(){
    unsigned char a;
    a= ~( (~0) << (1<<2));
    printf("%d",a);// impprime 15
}
