#include <stdio.h>
#include <stdlib.h>
//Final de diciembre 2016
//Ejercicio 1 Completar donde falta
/*int* cargarArr();
int sumPares(int* arr);
int main()
{
    int* arr=NULL;
    arr=cargarArr();
    printf("%d\nsuma pares:%d",*(arr+1),sumPares(arr));
    return 0;
}
int* cargarArr(){
    int *arr=NULL,i=0,n=0;
    arr=malloc(sizeof(int));
    printf("ingrese numeros: ");
    scanf("%d",&n);
    *(arr)=n;
    while(n!=0){
        printf("ingrese numeros: ");
        scanf("%d",&n);
        i++;
        arr=realloc(arr,(i+1)*(sizeof(int)));
        *(arr+i)=n;
    }
    return arr;
}
int sumPares(int* arr)
{
    if(*arr!=0){
        if(((*(arr))%2)==0){
            return (*(arr)+sumPares(arr+1));
        }else{
            return sumPares(arr+1);
        }
    }
    return 0;
}*/

//Ejercicio2
//Ejercicio 2.1
/*int main()
{
    unsigned char a=1; //recordar que es char por lo que solo tiene ocho bits, al leerlo como entero en el print, solo va a leer el valor de esos ocho bits
    unsigned int i;
    for(i=0;i<8;i++)
    {
    a=a&(1<<i); // el 1 es un entero al terminar este ciclo se va a pasar del primer octeto por lo que va a causar una operacion que le de como resultad nulo a la variable a
    }// es mas a partir de la segunda iteracion a se vuelve 0 por lo que todas las operaciones and binario dan como resultado 0
    printf("\n%d",a);// esto imprime 0
}*/

//Ejercicio 2.2
/*char f(char a)
{
    if (a<'c')
        f(a+1);// es un llamado recursivo, pero lo que devuelve no lo guarda en una variable, y tampoco afecta a la variable a

    else{
    if (a=='b')
        f(a+1);
    }
    return a;
}
void main()
{
    printf("%c",f('b'));// Esto imprime b
}*/

//Ejercicio 2.3
/*int main()
{   int* p=NULL;
    (*p)=10; // esta linea causa error de ejecucion, porqque se esta tratando de acceder al contenido de una direccion con el * pero p sigo siendo NULL

    printf("%d",*(p)+1); //el programa nunca llega a esta linea, si p tuviera la direccion de una variable int o tuviera un espacio de memoria dinamcia asignado esto correria sin problema e imprimiria 11 (es mas si fuera *p+1 tambien imrpimiria 11)
  return 0; //teniendo en cuenta el ultimo caso mencionado(el que incluye memoria asignada) *(p+1)+1 correria sin causar error pero se imprimiria basura
}*/

//Ejercicio 2.4
/*void f()
{   int a=9, b=13;
    int *bb, *cc;

    bb=&b;
    cc= &bb; //cc no se usa para nada en este codigo y esto no causa problema ya que cc es un doble puntero, por lo que se espera asignarle la direccion de memoria de un puntero
    printf("%d", *bb+1); //La falta de perentesisi alrededor de bb no importa y se logra acceder al contenido de la direccion de memoria que guarda bb (lo cual es 13) y 13 +1 es igual a 14
}
int main(){
    f();
}*/
struct s_nodo_bin
{
int codigoDelVendedor;
char nombreVendedor[30];
int objetivoTarjetasAnual;
double sueldoAnual;
struct s_nodo_bin* izq;
struct s_nodo_bin* der;
};
typedef struct s_nodo_bin* t_nodo_bin;
typedef struct sVenTar
{
    int codVen;
    char mesVenta[25];
    int canTar;
}tVenTar;
int cargarArbolVendedores(t_nodo_bin* arbol,FILE* fVende);
void agregar(t_nodo_bin* arbol, int id, char nombre[30], int objetivo, int sueldo);
void inorder(t_nodo_bin arbol);
int liquidar(t_nodo_bin arbol,int idVen);
int totalDetarjetasVendidas(int idVen);
void imprimirDatosDelarbol(t_nodo_bin arbol,int idVen);

int main(){
    FILE* fVende;
    t_nodo_bin arbol=NULL;
    fVende=fopen("vendedores.txt","r");
    cargarArbolVendedores(&arbol,fVende);
    inorder(arbol);
    liquidar(arbol,1);
    return 0;
}
/*int cargarArbolVendedores(t_nodo_bin* arbol,FILE* fVende){
    int id,objetivo,log,i;
    double sueldo;
    char log2;
    char nombre[30];
    while(log!=EOF && log2!=EOF){
        log=fscanf(fVende,"%d",&id);
        log2=fgetc(fVende);
        log2=fgetc(fVende);
        for(i=0;log2!=',';i++){
            nombre[i]=log2;
            log2=fgetc(fVende);
        }
        nombre[i]='\0';
        log=fscanf(fVende,"%d",&objetivo);
        log2=fgetc(fVende);
        log=fscanf(fVende,"%lf",&sueldo);
        log2=fgetc(fVende);
        agregar(arbol,id,nombre,objetivo,sueldo);
    }
    return 0;
}*/
int cargarArbolVendedores(t_nodo_bin* arbol,FILE* fVende){
    int id,objetivo,log,i;
    double sueldo;
    char log2;
    char nombre[30];
    while(log!=EOF && log2!=EOF){
        log=fscanf(fVende,"%d,",&id);
        log2=fgetc(fVende);
        for(i=0;log2!=',';i++){
            nombre[i]=log2;
            log2=fgetc(fVende);
        }
        nombre[i]='\0';
        log=fscanf(fVende,"%d,",&objetivo);
        log=fscanf(fVende,"%lf",&sueldo);
        log2=fgetc(fVende);
        agregar(arbol,id,nombre,objetivo,sueldo);
    }
    return 0;
}
void agregar(t_nodo_bin* arbol, int id, char nombre[30], int objetivo, int sueldo){
    int i=0;
    if (*arbol == NULL){
        *arbol = (t_nodo_bin)malloc(sizeof(struct s_nodo_bin));
        (*(*arbol)).codigoDelVendedor = id;
        while(nombre[i]!='\0'){
        (*(*arbol)).nombreVendedor[i] = nombre[i];
        i++;
        }
        (*(*arbol)).objetivoTarjetasAnual = objetivo;
        (*(*arbol)).sueldoAnual = sueldo;
        (*(*arbol)).izq = NULL;
        (*(*arbol)).der = NULL;
    }else{
    if (id < (*(*arbol)).codigoDelVendedor)
        agregar(& (*(*arbol)).izq,id,nombre,objetivo,sueldo);
    else
        agregar(& (*(*arbol)).der,id,nombre,objetivo,sueldo);
    }
}
void inorder(t_nodo_bin arbol){
    if (arbol != NULL){
        inorder((*arbol).izq);
        printf("%d,%s,%d,%lf\n", (*arbol).codigoDelVendedor,(*arbol).nombreVendedor,(*arbol).objetivoTarjetasAnual,(*arbol).sueldoAnual);
        inorder((*arbol).der);
    }
}
int totalDetarjetasVendidas(int idVen){
    FILE* fichero; //fichero=ventas
    fichero=fopen("ventasTarjetas.dat","rb");
    int  i=0,totalDeVentas=0;
    tVenTar* leer=NULL;
    leer=malloc(sizeof(tVenTar));
    fread( (leer+i), sizeof(tVenTar), 1, fichero );
    while(!feof(fichero))
    {
        printf("%d\t%s\t%d\t\n", leer[i].codVen,leer[i].mesVenta,leer[i].canTar);
        if((*(leer+i)).codVen==idVen){ //*
            totalDeVentas+=(*(leer+i)).canTar;
        }
        i++;
        leer=realloc(leer,(i+1)*sizeof(tVenTar));
        fread( (leer+i), sizeof(tVenTar), 1, fichero );
    }
    /*(*(leer+i)).codVen=0;
    i=0;
    while((*(leer+i)).codVen!=0){
        if((*(leer+i)).codVen==idVen){
            totalDeVentas=(totalDeVentas)+(*(leer+i)).canTar;
        }
        i++;
    }*/ //esto se remplazo por el *
    free(leer);
    fclose(fichero);
    return totalDeVentas;
}
void imprimirDatosDelarbol(t_nodo_bin arbol,int idVen){
    if(arbol==NULL){
        printf("no se encontro al vendedor");
    }else{
        if((*arbol).codigoDelVendedor==idVen){
            printf("Vendedor:%s\nid:%d\nobjetivo anual:%d\n",(*arbol).nombreVendedor,(*arbol).codigoDelVendedor,(*arbol).objetivoTarjetasAnual);
        }else{
            if (idVen < (*arbol).codigoDelVendedor)
                return imprimirDatosDelarbol((*arbol).izq, idVen);
            else
                return imprimirDatosDelarbol((*arbol).der, idVen);
        }
    }
}
int liquidar(t_nodo_bin arbol,int idVen){
    int total;
    total=totalDetarjetasVendidas(idVen);
    imprimirDatosDelarbol(arbol,idVen);
    printf("Total de tarjetas vendidas:%d",total);
    return 0;
}
