#include <stdio.h>
#include <stdlib.h>
// final de diciembre 2013

//Ejercicio 1.1
/*typedef struct s_nodo_bin
{
    int dato;
    struct s_nodo_bin* pIzq;
    struct s_nodo_bin* pDer;
} *t_nodo_bin_ptr;
int descendientes(t_nodo_bin_ptr arb)
{
    if(arb!=NULL)
    {
        return 1+descendientes((*arb).pIzq)+descendientes((*arb).pDer); //esta era la unica linea a completar
    }
    else
    {
    return 0;
    }
}
void agregar(t_nodo_bin_ptr* arbol, int valor){ //esta funcion solo fue para comprobar los resultados
    if (*arbol == NULL){
        *arbol = (t_nodo_bin_ptr)malloc(sizeof(struct s_nodo_bin));
        (*(*arbol)).dato = valor;
        (*(*arbol)).pIzq = NULL;
        (*(*arbol)).pDer = NULL;
    }else{
    if (valor < (*(*arbol)).dato)
        agregar(& (*(*arbol)).pIzq, valor);
    else
        agregar(& (*(*arbol)).pDer, valor);
    }
}
int main()
{
    t_nodo_bin_ptr arbol=NULL;
    agregar(&arbol,10);
    agregar(&arbol,15);
    agregar(&arbol,18);
    agregar(&arbol,12);
    agregar(&arbol,8);
    agregar(&arbol,5);
    agregar(&arbol,2);
    printf("%d",descendientes(arbol));
    return 0;
}*/

//Ejercicio1.2 Este me lo salteo porque es de listas doblemente enlazadas

//Ejercicio2.1
/*int doble(int valor)
{
    int entero=16;
    entero=(valor<<20)&16; //valor se va del primer octeto (y el primer octeto queda todo en 0) por lo que hacer eso y un & con 16 da como resultado 0
    return entero;
}
int main(){
    printf("%d",doble(1)); //imprime 0
}*/

//Ejercicio2.2
/*int main()
{
    char *ptrA = "Juan"; //en la posicion 4 tiene un \0
    char *ptrB = "Pedro";

    ptrA = ptrA + 4;
    for(;*ptrB!='\0';ptrB++); //esto lee hasta el \0
    printf("%c", *ptrA); no muestra nada el codigo (trata de imprimirse un \0)
}*/

//Ejercicio2.3
/*int main(){
    unsigned char a;
    a= ~0 << ((sizeof(unsigned char)*8)-1); // ~ esto significa complemento, invierte todos los bits (sin el -1 esto se iria de los 8 bits del char y nos deja un 0)
    printf("%d",a); //el resultado es 128
}*/
//Ejercicio2.4
char x (char a)
{
    if (a<='c')
        printf("%c", x(a+1)); //recursiva se hace 4 veces en esta parte se imprime z 3 veces, la 4 vez que se devuelve z es al main
    else
        printf("b"); // en el cuarto llamado se imprime b y se sale de la recursividad
    return 'z'; // se devuelve 'z' 4 veces
}
void main()
{ printf("%c",x('a')); //imprime
}
