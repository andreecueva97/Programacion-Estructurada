#include <stdio.h>
#include <stdlib.h>
//final de febrero 2013
//Ejercicio2.1
/*int retorno(int valor)
{
    if( valor != (valor&&valor) ) // si valor=1 esto da falso porque 1&&1 es igual a 1 lo cual es igual a valor,si valor=0 esto da falso porque 0&&0 es igual a 0 lo cual es igual a valor
    { //pero si tomamos 2 o otro valor distinto a 1 y 0 este if se cumple porque 2&&2 es igual a 1 lo cual es distinto a valor
        retorno(valor&valor); //al entrar en la recursiva quedamos en un loop infinito por lo que la funcion no retorna
        if(valor!=1)
        return 144;
    }
    return 266;
}
int main()
{
    int ret=2;
    ret=retorno(ret);
    printf("%d",ret);
    return 0;
}*/

//Ejercicio2.2
/*int main()
{
    int a[]={1,3,5,7,9,0};
    int *uno=NULL, dos=0;
    uno = a;
    dos= *(uno + *uno); //esto es igual a *(uno+1) ya que *(uno) es igual a 1 (primera posicion de a)
    printf("dos: %d\n", dos); //se imprime 3
    return 0;
}*/

//Ejercicio2.3 Este es el mismo que el de la practica 4 de final me lo salteo

//Ejercicio2.4
int main(){
    int a=2,b=32; //El resultado depende tanto de a como de b
    printf("%d",a<<b);
    if ( (a << b) > a )
    printf("rojo");
    else
    printf("negro");
}
