#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
//Final de julio 2017
//Ejercicio 1 completar donde falta
/*struct s_per{
    int dni,a;
};
typedef struct s_per t_per;
void ordenar(t_per** per);
void cargarString (char** str);
int main()
{
    char *str=NULL;
    printf("Hello world!\n");
    cargarString(&str);
    printf("\n%s",str);
    free(str);
    return 0;
}
void cargarString (char** str)
{
    int i=0;char aux="";
    (*str)=malloc(sizeof(char));
    aux=getche();
    while(aux!='\r')
{
    (*(*str+i))=aux;
    i++;
    (*str)=realloc((*str),(i+1)*sizeof(char));
    aux=getche();
}
    (*(*str+i))='\0';
}
void ordenar(t_per** per) //el ejercicio no aclara con que valor finaliza el arreglo ni tampoco nos da un tamanio, por lo que voy a asumir que termina con 0 la carga
{
    int i=0,j=0; t_per aux;
    for(i=0;(*(*per+i)).dni!=0;i++)
    {
        for(j=i+1;(*(*per+j)).dni!=0;j++)
        {
            if((*(*per+i)).dni<(*(*per+j)).dni)
            {
                aux=(*(*per+i));
                (*(*per+i))=(*(*per+j));
                (*(*per+j))=aux;
            }
        }
    }
}*/

//Ejercicio2.1
/*int foo(int n,int m);
int main(){
    printf("%d",foo(3,4));
    return 0;
}
int foo(int n,int m){
    int miFoo=1;
    if(m>0){
        miFoo=n*foo(n,m-1);
    }
    return miFoo;
}*/

//Ejercicio2.2
/*int main()
{
char* s[5]; int i=0;
char c='2';
    s[i]=&c;
    for(i=0;i<5;i++){
        s[i]=&c;
        c=c+1;
    }               //false   not(true)=false osea 0 y 0
printf("(%d, %d)", (c=='2'), !(s[0]==&c)); // aca c=7 y s[0]=&c es mas todas las posiciones de s contienen la misma direccion de memoria
return 0; //el resultado es (0,0)
}*/

//Ejercicio2.3
/*int main(){
char* s=NULL; int i; //este programa tiene error de ejecucion
    //s=malloc(5); //esta es la linea que le faltaria para funcionar correctamente
    for(i=0;i<4;i++){
        *(s+i)='a'+i;// aca sin la linea que comente (la cual la agrege yo) causa error porque s no tendria suficiente memoria para lograr esta asignacion
    }
    s[i]='\0';
    printf("%s",s); //de no ser por el error esto imprimiria abcd en minuscula
return 0;
}*/

//Ejercicio2.4
/*int foo(unsigned char n,unsigned char filter){
    return n&((255&(filter<<n+n))>1); //la expresion queda asi 3&((255&(256))>1)
    //si la expresion fuera n&((255&((filter<<n)+n))>1) daria 1
    //por culpa de la comparacion solo hay dos posibles resultados 1 o 0
}
int main(){
    printf("%d",foo(3,4));
    return 0; //el resultado es 0
}*/

//Ejercicio3
struct s_nodo{
    int id,promedio,max,min;
    char nombre[200];
    struct s_nodo* sig;
};
typedef struct s_nodo* t_nodo;

struct s_nodo2{
    int id,promedio,max,min;
    double cotaMax,cotaMin;
    char nombre[200];
    struct s_nodo2* sig;
};
typedef struct s_nodo2* t_nodo2;

struct s_localidades{
    int id,promedio,max,min;
    char nombre[200];
};
typedef struct s_localidades t_localidades;
t_nodo maxCinco(int n,int anio);

void agregar(t_nodo* lista,int id,int promedio,int max,int min,char nombre[200]){
    int i=0;
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).id=id;
        (**lista).promedio=promedio;
        (**lista).max=max;
        (**lista).min=min;
        while(nombre[i]!='\0'){
            (**lista).nombre[i]=nombre[i];
            i++;
        }
        (**lista).nombre[i]='\0';
        (**lista).sig=NULL;
    }else{
        agregar(&((**lista).sig),id,promedio,max,min,nombre);
    }
}
void insertarOrdenadamente(t_nodo2* lista,int id,int promedio,int max,int min,char nombre[200],int cotaM,int cotam){
    t_nodo2 aux=NULL;
    int i=0;
    if((cotaM-promedio)>0){
        if(*lista==NULL || (cotaM-promedio)>(((**lista).cotaMax)-((**lista).promedio))){
            aux = (t_nodo2) malloc(sizeof(struct s_nodo2));
            (*aux).id=id;
            (*aux).promedio=promedio;
            (*aux).max=max;
            (*aux).min=min;
            (*aux).cotaMax=cotaM;
            (*aux).cotaMin=cotam;
            while(nombre[i]!='\0'){
                (*aux).nombre[i]=nombre[i];
                i++;
            }
            (*aux).nombre[i]='\0';
            (*aux).sig=*lista;
            *lista=aux;
        }else{
            insertarOrdenadamente(&((**lista).sig),id,promedio,max,min,nombre,cotaM,cotam);
        }
    }
}
void imprimirListaNormalmente(t_nodo lista){
    if(lista!=NULL){
        printf("%d",(*lista).id);
        imprimirListaNormalmente((*lista).sig);
    }
}
void imprimirListaNormalmente2(t_nodo2 lista){
    if(lista!=NULL){
        printf("%d",(*lista).id);
        imprimirListaNormalmente2((*lista).sig);
    }
}
int agregarPromedio(int id,int anio){
    FILE* alturas;
    int log,id2,suma=0,division=0;
    double altura;
    unsigned int anio2=0;
    alturas=fopen("alturas.txt","r");
    log=fscanf(alturas,"%d, %lf, %d\n", &id2, &altura,&anio2);
    while(log!=EOF){
        if(id2==id && ((anio2>>2)&2047)==anio){
            suma+=altura;
            division++;
        }
        log=fscanf(alturas,"%d, %lf, %d\n", &id2, &altura,&anio2);
    }
    fclose(alturas);
    if(division!=0){
        return (suma/division);
    }else{
        return suma;
    }
}
int agregarMaximo(int id,int anio){
    FILE* alturas;
    int log,id2,max=0;
    double altura;
    unsigned int anio2=0;
    alturas=fopen("alturas.txt","r");
    log=fscanf(alturas,"%d, %lf, %d\n", &id2, &altura,&anio2);
    while(log!=EOF){
        if(id2==id && ((anio2>>2)&2047)==anio){
            if(altura>max){
                max=altura;
            }
        }
        log=fscanf(alturas,"%d, %lf, %d\n", &id2, &altura,&anio2);
    }
    fclose(alturas);
    return max;
}
int agregarMinimo(int id,int anio){
    FILE* alturas;
    int log,id2,min=0,contador=0;
    double altura;
    unsigned int anio2=0;
    alturas=fopen("alturas.txt","r");
    log=fscanf(alturas,"%d, %lf, %d\n", &id2, &altura,&anio2);
    while(log!=EOF){
        if(id2==id && ((anio2>>2)&2047)==anio){
            if(contador==0){
                min=altura;
                contador++;
            }
            if(altura>min){
                min=altura;
            }
        }
        log=fscanf(alturas,"%d, %lf, %d\n", &id2, &altura,&anio2);
    }
    fclose(alturas);
    return min;
}
t_nodo maxCinco(int n,int anio){
    int i=0,j=0,log,id;
    char log2;
    FILE* localidades;
    localidades=fopen("localidades.txt","r");
    t_localidades* arr=NULL;
    arr=malloc(sizeof(t_localidades));
    log=fscanf(localidades,"%d,",&id);
    while(log!=EOF && log2!=EOF){
        (*(arr+i)).id=id;
        log2=fgetc(localidades);
        while(log2!='\n' && log2!=EOF){
            (*(arr+i)).nombre[j]=log2;
            j++;
            log2=fgetc(localidades);
        }
        (*(arr+i)).nombre[j]='\0';
        printf("%d:%s----",(*(arr+i)).id,((*(arr+i)).nombre));
        i++;
        j=0;
        arr=realloc(arr,(i+1)*sizeof(t_localidades));
        log=fscanf(localidades,"%d,",&id);
    }
    (*(arr+i)).id=0;
    i=0;
    while((*(arr+i)).id!=0){
        (*(arr+i)).promedio=agregarPromedio((*(arr+i)).id,anio);
        (*(arr+i)).max=agregarMaximo((*(arr+i)).id,anio);
        (*(arr+i)).min=agregarMinimo((*(arr+i)).id,anio);
        i++;
    }
    t_localidades aux;
    for(i=0;(*(arr+i)).id!=0;i++){
        for(j=i+1;(*(arr+j)).id!=0;j++){
            if((*(arr+j)).promedio>(*(arr+i)).promedio){
                aux=(*(arr+i));
                (*(arr+i))=(*(arr+j));
                (*(arr+j))=aux;
            }
        }
    }
    printf("\n%d %d\n",(*(arr+0)).id,(*(arr+0)).promedio);
    printf("\n%d %d\n",(*(arr+1)).id,(*(arr+1)).promedio);
    printf("\n%d %d\n",(*(arr+2)).id,(*(arr+2)).promedio);
    printf("\n%d %d\n",(*(arr+3)).id,(*(arr+3)).promedio);
    printf("\n%d %d\n",(*(arr+4)).id,(*(arr+4)).promedio);
    i=0;
    j=0;
    t_nodo lista=NULL;
    while((*(arr+i)).id!=0 && j<n){
        if((*(arr+i)).promedio!=0){ // realmente el if no es necesario
            agregar(&lista,(*(arr+i)).id,(*(arr+i)).promedio,(*(arr+i)).max,(*(arr+i)).min,(*(arr+i)).nombre);
            j++;
        }
        i++;
    }
    free(arr);
    fclose(localidades);
    return lista;
}
int cotaMaxima(int id){
    FILE* cotas;
    cotas=fopen("cotas.txt","r");
    int log,id2;
    double cotaM=0,cotam=0;
    log=fscanf(cotas,"%d, %lf, %lf\n", &id2, &cotam,&cotaM);
    while(log!=EOF){
        if(id2==id){
            fclose(cotas);
            return cotaM;
        }
        log=fscanf(cotas,"%d, %lf, %lf\n", &id2, &cotam,&cotaM);
    }
    fclose(cotas);
    return cotaM;
}
/*int cotaMaxima(int id){ //otra alternativa que es menos eficiente
    FILE* cotas;
    cotas=fopen("cotas.txt","r");
    int log,id2;
    double cotaM,cotam,cotaM2=0;
    log=fscanf(cotas,"%d, %lf, %lf\n", &id2, &cotam,&cotaM);
    while(log!=EOF){
        if(id2==id){
            cotaM2=cotaM;
        }
        log=fscanf(cotas,"%d, %lf, %lf\n", &id2, &cotam,&cotaM);
    }
    fclose(cotas);
    return cotaM2;
}*/
int cotaMinima(int id){
    FILE* cotas;
    cotas=fopen("cotas.txt","r");
    int log,id2;
    double cotaM=0,cotam=0;
    log=fscanf(cotas,"%d, %lf, %lf\n", &id2, &cotam,&cotaM);
    while(log!=EOF){
        if(id2==id){
            fclose(cotas);
            return cotam;
        }
        log=fscanf(cotas,"%d, %lf, %lf\n", &id2, &cotam,&cotaM);
    }
    fclose(cotas);
    return cotam;
}
t_nodo2 ordenarPorCota(t_nodo lista){
    t_nodo aux=NULL;
    t_nodo2 lista2=NULL;
    int cotaM,cotam;
    aux=lista;
    while(aux!=NULL){
        cotaM=cotaMaxima((*aux).id);
        cotam=cotaMinima((*aux).id);
        insertarOrdenadamente(&lista2,(*aux).id,(*aux).promedio,(*aux).max,(*aux).min,(*aux).nombre,cotaM,cotam);
        aux=(*aux).sig;
    }
    return lista2;
}
int main(){
    t_nodo lista=NULL;
    t_nodo2 lista2=NULL;
    lista=maxCinco(3,691);
    imprimirListaNormalmente(lista);
    lista2=ordenarPorCota(lista);
    imprimirListaNormalmente2(lista2);
    return 0;
}
