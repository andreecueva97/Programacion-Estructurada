#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
struct s_nodo
{
int valor;
struct s_nodo* sig;
};
typedef struct s_nodo* t_nodo;
struct s_cola
{
t_nodo frente;
t_nodo final;
};
typedef struct s_cola t_cola;
void agregar(t_nodo* lista, int valor);
void agregarYImprimirNormalmente(t_nodo* lista, int valor);
void agregarYImprimirInversamente(t_nodo* lista, int valor);
void imprimirListaNormalmente(t_nodo lista);
void imprimirListaInversamente(t_nodo lista);
void insertarOrdenadamente(t_nodo* lista, int valor);
void eliminarPorValor(t_nodo* lista, int valor);
void eliminarPorPosicion(t_nodo* lista, int posicion);
void push(t_nodo* pila,int valor);
int pop(t_nodo* pila);
void queue(t_cola* cola,int valor);
int dequeue(t_cola* cola);
int esta(t_nodo lista,int valor);
void unio(t_nodo a,t_nodo b);
void interseccion(t_nodo a,t_nodo b);
void diferencia(t_nodo a,t_nodo b);
void diferenciaSimetrica(t_nodo a,t_nodo b);
void conjuntosConPilas(t_nodo* a,t_nodo* b);
void conjuntosConColas(t_cola* a,t_cola* b);
void liberarLista(t_nodo* lista);
int main()
{
    int valor;
    t_nodo pila=NULL;
    t_nodo pila2=NULL;
    t_nodo aux=NULL;
    printf("Ingrese los datos de la pila (0 para finalizar):");
    scanf("%d",&valor);
    while(valor!=0){
        push(&pila,valor);
        printf("Ingrese los datos de la pila (0 para finalizar):");
        scanf("%d",&valor);
    }
    printf("Ingrese los datos de la pila (0 para finalizar):");
    scanf("%d",&valor);
    while(valor!=0){
        push(&pila2,valor);
        printf("Ingrese los datos de la pila (0 para finalizar):");
        scanf("%d",&valor);
    }
    conjuntosConPilas(&pila,&pila2);
    while(pila!=NULL){
        valor=pop(&pila);
        push(&aux,valor);
        printf("%d\n",valor);
    }
    while(aux!=NULL){
        valor=pop(&aux);
        push(&pila,valor);
        printf("%d\n",valor);
    }
    t_cola cola={NULL,NULL};
    t_cola cola2={NULL,NULL};
    t_cola aux2={NULL,NULL};
    printf("Ingrese los datos de la cola (0 para finalizar):");
    scanf("%d",&valor);
    while(valor!=0){
        queue(&cola,valor);
        printf("Ingrese los datos de la cola (0 para finalizar):");
        scanf("%d",&valor);
    }
    printf("Ingrese los datos de la cola (0 para finalizar):");
    scanf("%d",&valor);
    while(valor!=0){
        queue(&cola2,valor);
        printf("Ingrese los datos de la cola (0 para finalizar):");
        scanf("%d",&valor);
    }
    conjuntosConColas(&cola,&cola2);
    while(cola.frente!=NULL){
        valor=dequeue(&cola);
        queue(&aux2,valor);
        printf("%d-",valor);
    }
    while(aux2.frente!=NULL){
        valor=dequeue(&aux2);
        queue(&cola,valor);
        printf("%d-",valor);
    }
    return 0;
}
void agregar(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregar(&((**lista).sig),valor);
    }
}
void agregarYImprimirNormalmente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
        printf("%d",((**lista).valor));
    }else{
        printf("%d",((**lista).valor));
        agregarYImprimirNormalmente(&((**lista).sig),valor);
    }
}
void agregarYImprimirInversamente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregarYImprimirInversamente(&((**lista).sig),valor);
    }
    printf("%d",((**lista).valor));
}
void imprimirListaInversamente(t_nodo lista){
    if((*lista).sig!=NULL){
        imprimirListaInversamente((*lista).sig);
    }
    printf("%d",(*lista).valor);
}
void imprimirListaNormalmente(t_nodo lista){
    if(lista!=NULL){
        printf("%d",(*lista).valor);
        imprimirListaNormalmente((*lista).sig);
    }
}
void insertarOrdenadamente(t_nodo* lista, int valor){
    t_nodo aux=NULL;
    if(*lista==NULL || valor<(**lista).valor){
        aux = (t_nodo) malloc(sizeof(struct s_nodo));
        (*aux).valor=valor;
        (*aux).sig=*lista;
        *lista=aux;
    }else{
        insertarOrdenadamente(&((**lista).sig),valor);
    }
}
void eliminarPorValor(t_nodo* lista, int valor){
    if((*lista)==NULL){
        printf("Error, lista vacia o el valor no se encontro\n");
    }else if((**lista).valor==valor){
        t_nodo aux=NULL;
        aux=(*lista);
        (*lista)=(**lista).sig;
        free(aux);
    }else{
        eliminarPorValor(&(**lista).sig,valor);
    }
}
void eliminarPorPosicion(t_nodo* lista, int posicion){
    int i=0,log=0;
    t_nodo aux=NULL;
    aux=(*lista);
    while((*lista)!=NULL && log!=1){
        if(i==posicion){
            (*lista)=(**lista).sig;
            free(aux);
            log=1;
        }else{
            lista=&((**lista).sig);
            aux=(*lista);
            i++;
        }
    }
    if(aux!=NULL){
        free(aux);
    }
    if(log==0){
        printf("Error, lista vacia o la posicion no encontrada\n");
    }
}
void push(t_nodo* pila,int valor){
    t_nodo aux=(t_nodo)malloc(sizeof(struct s_nodo));
    (*aux).valor=valor;
    (*aux).sig=NULL;
    (*aux).sig=(*pila);
    (*pila)=aux;
}
int pop(t_nodo* pila){
    int valor;
    t_nodo aux=(*pila);
    valor=(*aux).valor;
    (*pila)=(*aux).sig;
    free(aux);
    return valor;
}
void queue(t_cola* cola,int valor){
    t_nodo aux=(t_nodo) malloc(sizeof(struct s_nodo));
    (*aux).valor=valor;
    (*aux).sig=NULL;
    if ((*cola).frente == NULL && (*cola).final == NULL){
        (*cola).frente=aux;
        (*cola).final=aux;
    }else{
        cola->final->sig=aux;
        (*cola).final=aux;
    }
}
int dequeue(t_cola* cola){
    int valor;
    t_nodo aux=(*cola).frente;
    (*cola).frente=cola->frente->sig;
    valor=(*aux).valor;
    free(aux);
    if ((*cola).frente==NULL){
        (*cola).final=NULL;
    }
    return valor;
}
int esta(t_nodo lista,int valor){
    if(lista==NULL){
        return 0;
    }else{
        if((*lista).valor==valor){
            return 1;
        }else{
            return esta((*lista).sig,valor);
        }
    }
}
void unio(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        agregar(&c,(*aux).valor);
        aux=(*aux).sig;
    }
    aux=b;
    while(aux!=NULL){
        if(esta(c,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void interseccion(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        if(esta(b,(*aux).valor)==1){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void diferencia(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        if(esta(b,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void diferenciaSimetrica(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        if(esta(b,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    aux=NULL;
    aux=b;
    while(aux!=NULL){
        if(esta(a,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void conjuntosConPilas(t_nodo* a,t_nodo* b){
    t_nodo conjuntoA=NULL;
    t_nodo conjuntoB=NULL;
    t_nodo aux=NULL;
    int valor;
    while(*a!=NULL){
        valor=pop(a);
        push(&aux,valor);
        agregar(&conjuntoA,valor);
    }
    while(aux!=NULL){
        valor=pop(&aux);
        push(a,valor);
    }
    while(*b!=NULL){
        valor=pop(b);
        push(&aux,valor);
        agregar(&conjuntoB,valor);
    }
    while(aux!=NULL){
        valor=pop(&aux);
        push(b,valor);
    }
    printf("\n Ingrese una opcion\n0.finalizar\n1.union\n2.interseccion\n3.diferencia\n4.diferencia simetrica\n");
    scanf("%d",&valor);
    while(valor!=0){
        if(valor==1)
            unio(conjuntoA,conjuntoB);
        if(valor==2)
            interseccion(conjuntoA,conjuntoB);
        if(valor==3)
            diferencia(conjuntoA,conjuntoB);
        if(valor==4)
            diferenciaSimetrica(conjuntoA,conjuntoB);
        printf("\n Ingrese una opcion\n0.finalizar\n1.union\n2.interseccion\n3.diferencia\n4.diferencia simetrica\n");
        scanf("%d",&valor);
    }
    liberarLista(&conjuntoA);
    liberarLista(&conjuntoB);
}
void conjuntosConColas(t_cola* a,t_cola* b){
    t_nodo conjuntoA=NULL;
    t_nodo conjuntoB=NULL;
    t_cola aux={NULL,NULL};
    int valor;
    while((*a).frente!=NULL){
        valor=dequeue(a);
        queue(&aux,valor);
        agregar(&conjuntoA,valor);
    }
    while(aux.frente!=NULL){
        valor=dequeue(&aux);
        queue(a,valor);
    }
    while((*b).frente!=NULL){
        valor=dequeue(b);
        queue(&aux,valor);
        agregar(&conjuntoB,valor);
    }
    while(aux.frente!=NULL){
        valor=dequeue(&aux);
        queue(b,valor);
    }
    printf("\n Ingrese una opcion\n0.finalizar\n1.union\n2.interseccion\n3.diferencia\n4.diferencia simetrica\n");
    scanf("%d",&valor);
    while(valor!=0){
        if(valor==1)
            unio(conjuntoA,conjuntoB);
        if(valor==2)
            interseccion(conjuntoA,conjuntoB);
        if(valor==3)
            diferencia(conjuntoA,conjuntoB);
        if(valor==4)
            diferenciaSimetrica(conjuntoA,conjuntoB);
        printf("\n Ingrese una opcion\n0.finalizar\n1.union\n2.interseccion\n3.diferencia\n4.diferencia simetrica\n");
        scanf("%d",&valor);
    }
    liberarLista(&conjuntoA);
    liberarLista(&conjuntoB);
}
void liberarLista(t_nodo* lista){
    if(*lista!=NULL){
        liberarLista(&(**lista).sig);
        free(*lista);
        *lista=NULL;
    }
}
