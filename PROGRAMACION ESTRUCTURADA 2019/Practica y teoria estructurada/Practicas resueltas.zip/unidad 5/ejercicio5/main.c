#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
struct s_nodo
{
int valor;
struct s_nodo* sig;
};
typedef struct s_nodo* t_nodo;
struct s_cola
{
t_nodo frente;
t_nodo final;
};
typedef struct s_cola t_cola;
void agregar(t_nodo* lista, int valor);
void agregarYImprimirNormalmente(t_nodo* lista, int valor);
void agregarYImprimirInversamente(t_nodo* lista, int valor);
void imprimirListaNormalmente(t_nodo lista);
void imprimirListaInversamente(t_nodo lista);
void insertarOrdenadamente(t_nodo* lista, int valor);
void eliminarPorValor(t_nodo* lista, int valor);
void eliminarPorPosicion(t_nodo* lista, int posicion);
void push(t_nodo* pila,int valor);
int pop(t_nodo* pila);
void queue(t_cola* cola,int valor);
int dequeue(t_cola* cola);
int main()
{
    int valor;
    t_nodo pila=NULL;
    printf("Ingrese los datos de la pila (0 para finalizar):");
    scanf("%d",&valor);
    while(valor!=0){
        push(&pila,valor);
        printf("Ingrese los datos de la pila (0 para finalizar):");
        scanf("%d",&valor);
    }
    while(pila!=NULL){
        valor=pop(&pila);
        printf("%d\n",valor);
    }
    t_cola cola={NULL,NULL};
    printf("Ingrese los datos de la cola (0 para finalizar):");
    scanf("%d",&valor);
    while(valor!=0){
        queue(&cola,valor);
        printf("Ingrese los datos de la cola (0 para finalizar):");
        scanf("%d",&valor);
    }
    while(cola.frente!=NULL){
        valor=dequeue(&cola);
        printf("%d-",valor);
    }
    return 0;
}
void agregar(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregar(&((**lista).sig),valor);
    }
}
void agregarYImprimirNormalmente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
        printf("%d",((**lista).valor));
    }else{
        printf("%d",((**lista).valor));
        agregarYImprimirNormalmente(&((**lista).sig),valor);
    }
}
void agregarYImprimirInversamente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregarYImprimirInversamente(&((**lista).sig),valor);
    }
    printf("%d",((**lista).valor));
}
void imprimirListaInversamente(t_nodo lista){
    if((*lista).sig!=NULL){
        imprimirListaInversamente((*lista).sig);
    }
    printf("%d",(*lista).valor);
}
void imprimirListaNormalmente(t_nodo lista){
    if(lista!=NULL){
        printf("%d",(*lista).valor);
        imprimirListaNormalmente((*lista).sig);
    }
}
void insertarOrdenadamente(t_nodo* lista, int valor){
    t_nodo aux=NULL;
    if(*lista==NULL || valor<(**lista).valor){
        aux = (t_nodo) malloc(sizeof(struct s_nodo));
        (*aux).valor=valor;
        (*aux).sig=*lista;
        *lista=aux;
    }else{
        insertarOrdenadamente(&((**lista).sig),valor);
    }
}
void eliminarPorValor(t_nodo* lista, int valor){
    if((*lista)==NULL){
        printf("Error, lista vacia o el valor no se encontro\n");
    }else if((**lista).valor==valor){
        t_nodo aux=NULL;
        aux=(*lista);
        (*lista)=(**lista).sig;
        free(aux);
    }else{
        eliminarPorValor(&(**lista).sig,valor);
    }
}
void eliminarPorPosicion(t_nodo* lista, int posicion){
    int i=0,log=0;
    t_nodo aux=NULL;
    aux=(*lista);
    while((*lista)!=NULL && log!=1){
        if(i==posicion){
            (*lista)=(**lista).sig;
            free(aux);
            log=1;
        }else{
            lista=&((**lista).sig);
            aux=(*lista);
            i++;
        }
    }
    if(aux!=NULL){
        free(aux);
    }
    if(log==0){
        printf("Error, lista vacia o la posicion no encontrada\n");
    }
}
void push(t_nodo* pila,int valor){
    t_nodo aux=(t_nodo)malloc(sizeof(struct s_nodo));
    (*aux).valor=valor;
    (*aux).sig=NULL;
    (*aux).sig=(*pila);
    (*pila)=aux;
}
int pop(t_nodo* pila){
    int valor;
    t_nodo aux=(*pila);
    valor=(*aux).valor;
    (*pila)=(*aux).sig;
    free(aux);
    return valor;
}
void queue(t_cola* cola,int valor){
    t_nodo aux=(t_nodo) malloc(sizeof(struct s_nodo));
    (*aux).valor=valor;
    (*aux).sig=NULL;
    if ((*cola).frente == NULL && (*cola).final == NULL){
        (*cola).frente=aux;
        (*cola).final=aux;
    }else{
        cola->final->sig=aux;
        (*cola).final=aux;
    }
}
int dequeue(t_cola* cola){
    int valor;
    t_nodo aux=(*cola).frente;
    (*cola).frente=cola->frente->sig;
    valor=(*aux).valor;
    free(aux);
    if ((*cola).frente==NULL){
        (*cola).final=NULL;
    }
    return valor;
}
