#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
struct s_nodo
{
int valor;
struct s_nodo* sig;
};
typedef struct s_nodo* t_nodo;
void agregar(t_nodo* lista, int valor);
void agregarYImprimirNormalmente(t_nodo* lista, int valor);
void agregarYImprimirInversamente(t_nodo* lista, int valor);
void imprimirListaNormalmente(t_nodo lista);
void imprimirListaInversamente(t_nodo lista);
void insertarOrdenadamente(t_nodo* lista, int valor);
void eliminarPorValor(t_nodo* lista, int valor);
void eliminarPorPosicion(t_nodo* lista, int posicion);
void eliminarPorPosicionRecursivamente(t_nodo* lista,int posicion);
void liberarLista(t_nodo* lista);
int esta(t_nodo lista,int valor);
void unio(t_nodo a,t_nodo b);
void interseccion(t_nodo a,t_nodo b);
void diferencia(t_nodo a,t_nodo b);
void diferenciaSimetrica(t_nodo a,t_nodo b);
int main()
{
    FILE* arch;
    arch=fopen("lista.txt","r");
    t_nodo conjuntoA=NULL;
    int valor,log;
    char log2;
    log=fscanf(arch,"%d",&valor);
    log2=fgetc(arch);
    while(log!=EOF && log2!='\n' && log2!=EOF){
        agregar(&conjuntoA,valor);
        log=fscanf(arch,"%d",&valor);
        log2=fgetc(arch);
        while(esta(conjuntoA,valor)!=0){
            log=fscanf(arch,"%d",&valor);
            log2=fgetc(arch);
        }
    }
    agregar(&conjuntoA,valor);
    imprimirListaNormalmente(conjuntoA);
    t_nodo conjuntoB=NULL;
    log=fscanf(arch,"%d",&valor);
    log2=fgetc(arch);
    while(log!=EOF && log2!='\n' && log2!=EOF){
        agregar(&conjuntoB,valor);
        log=fscanf(arch,"%d",&valor);
        log2=fgetc(arch);
        while(esta(conjuntoB,valor)!=0){
            log=fscanf(arch,"%d",&valor);
            log2=fgetc(arch);
        }
    }
    agregar(&conjuntoB,valor);
    imprimirListaNormalmente(conjuntoB);
    printf("\n Ingrese una opcion\n0.finalizar\n1.union\n2.interseccion\n3.diferencia\n4.diferencia simetrica\n");
    scanf("%d",&valor);
    while(valor!=0){
        if(valor==1)
            unio(conjuntoA,conjuntoB);
        if(valor==2)
            interseccion(conjuntoA,conjuntoB);
        if(valor==3)
            diferencia(conjuntoA,conjuntoB);
        if(valor==4)
            diferenciaSimetrica(conjuntoA,conjuntoB);
        printf("\n Ingrese una opcion\n0.finalizar\n1.union\n2.interseccion\n3.diferencia\n4.diferencia simetrica\n");
        scanf("%d",&valor);
    }
    fclose(arch);
    return 0;
}
void agregar(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregar(&((**lista).sig),valor);
    }
}
void agregarYImprimirNormalmente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
        printf("%d-",((**lista).valor));
    }else{
        printf("%d-",((**lista).valor));
        agregarYImprimirNormalmente(&((**lista).sig),valor);
    }
}
void agregarYImprimirInversamente(t_nodo* lista,int valor){
    if(*lista==NULL){
        *lista=(t_nodo) malloc(sizeof(struct s_nodo));
        (**lista).valor=valor;
        (**lista).sig=NULL;
    }else{
        agregarYImprimirInversamente(&((**lista).sig),valor);
    }
    printf("%d-",((**lista).valor));
}
void imprimirListaInversamente(t_nodo lista){
    if((*lista).sig!=NULL){
        imprimirListaInversamente((*lista).sig);
    }
    printf("%d-",(*lista).valor);
}
void imprimirListaNormalmente(t_nodo lista){
    if(lista!=NULL){
        printf("%d-",(*lista).valor);
        imprimirListaNormalmente((*lista).sig);
    }
}
void insertarOrdenadamente(t_nodo* lista, int valor){
    t_nodo aux=NULL;
    if(*lista==NULL || valor<(**lista).valor){
        aux = (t_nodo) malloc(sizeof(struct s_nodo));
        (*aux).valor=valor;
        (*aux).sig=*lista;
        *lista=aux;
    }else{
        insertarOrdenadamente(&((**lista).sig),valor);
    }
}
void eliminarPorValor(t_nodo* lista, int valor){
    if((*lista)==NULL){
        printf("Error, lista vacia o el valor no se encontro\n");
    }else if((**lista).valor==valor){
        t_nodo aux=NULL;
        aux=(*lista);
        (*lista)=(**lista).sig;
        free(aux);
    }else{
        eliminarPorValor(&(**lista).sig,valor);
    }
}
void eliminarPorPosicion(t_nodo* lista, int posicion){
    int i=0,log=0;
    t_nodo aux=NULL;
    aux=(*lista);
    while((*lista)!=NULL && log!=1){
        if(i==posicion){
            (*lista)=(**lista).sig;
            free(aux);
            log=1;
        }else{
            lista=&((**lista).sig);
            aux=(*lista);
            i++;
        }
    }
    if(aux!=NULL){
        free(aux);
    }
    if(log==0){
        printf("Error, lista vacia o la posicion no encontrada\n");
    }
}
void eliminarPorPosicionRecursivamente(t_nodo* lista,int posicion){
    if((*lista)!=NULL){
        if(((**lista).sig)==NULL || posicion==0){     //esto se hace asi si no se desea informar de errores y tambien para eliminar la ultimma poscicion en caso de que no se encuentre la posicion
            t_nodo aux=NULL;
            aux=(*lista);
            (*lista)=(**lista).sig;
            free(aux);
        }else{
            eliminarPorPosicionRecursivamente(&((**lista).sig),posicion-1);
        }
    }
}
void liberarLista(t_nodo* lista){
    if(*lista!=NULL){
        liberarLista(&(**lista).sig);
        free(*lista);
        *lista=NULL;
    }
}
int esta(t_nodo lista,int valor){
    if(lista==NULL){
        return 0;
    }else{
        if((*lista).valor==valor){
            return 1;
        }else{
            return esta((*lista).sig,valor);
        }
    }
}
void unio(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        agregar(&c,(*aux).valor);
        aux=(*aux).sig;
    }
    aux=b;
    while(aux!=NULL){
        if(esta(c,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void interseccion(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        if(esta(b,(*aux).valor)==1){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void diferencia(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        if(esta(b,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
void diferenciaSimetrica(t_nodo a,t_nodo b){
    t_nodo aux=NULL;
    t_nodo c=NULL;
    aux=a;
    while(aux!=NULL){
        if(esta(b,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    aux=NULL;
    aux=b;
    while(aux!=NULL){
        if(esta(a,(*aux).valor)==0){
            agregar(&c,(*aux).valor);
        }
        aux=(*aux).sig;
    }
    imprimirListaNormalmente(c);
    liberarLista(&c);
}
