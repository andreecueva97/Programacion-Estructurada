#include <stdio.h>
#include <stdlib.h>
struct s_personas{
    int documento;
    char nombre[25],pais[25];
};
typedef struct s_personas t_personas;
void cargarStructArrDeArch(int x,FILE *arch,struct s_personas p[x]);
void imprimirTabla(int x,struct s_personas p[x]);
int main(){
    FILE *arch;
    int tam=4;
    t_personas p[tam];
    arch=fopen("personas.txt","r");
    cargarStructArrDeArch(tam,arch,p);
    imprimirTabla(tam,p);
    fclose(arch);
    return 0;
}
void cargarStructArrDeArch(int x,FILE *arch,struct s_personas p[x]){
    int a,r,i=0,j=0;
    char caracter;
    r=fscanf(arch,"%d,",&a);
    while(i!=x && r!=EOF){
        p[i].documento=a;
        caracter=getc(arch);
        while(caracter!=',' && caracter!='\n'){
            p[i].nombre[j]=caracter;
            caracter=getc(arch);
            j++;
        }
        p[i].nombre[j]='\0';
        j=0;
        caracter=getc(arch);
        while(caracter!=',' && caracter!='\n'){
            p[i].pais[j]=caracter;
            caracter=getc(arch);
            j++;
        }
        p[i].pais[j]='\0';
        j=0;
        i++;
        r=fscanf(arch,"%d,",&a);
    }
}
void imprimirTabla(int x,struct s_personas p[x]){
    int i=0;
    printf("Documento     ");
    printf("Nombre           ");
    printf("Pais      ");
    printf("\n");
    printf("============================================");
    printf("\n");
    while(i!=x){
        printf("%-14d",p[i].documento);
        printf("%-17s",p[i].nombre);
        printf("%-10s",p[i].pais);
        printf("\n");
        i++;
    }
}
