#include <stdio.h>
#include <stdlib.h>
void guardarBitsCharEnUnEntero(unsigned char a,unsigned char b,unsigned char c,unsigned char d);
int main()
{
    unsigned char a,b,c,d;
    a=64;
    b=66;
    c=97;
    d=99;
    guardarBitsCharEnUnEntero(a,b,c,d);
    return 0;
}
void guardarBitsCharEnUnEntero(unsigned char a,unsigned char b,unsigned char c,unsigned char d){
    int i=0;
    unsigned int x,n;
    x=0;
    n=1;
    n=n<<31;
    x=x|a;
    x=x<<8;
    x=x|b;
    x=x<<8;
    x=x|c;
    x=x<<8;
    x=x|d;
    while(i!=32){
        if((x&n>>i)==0){
            printf("0");
        }else{
            printf("1");
        }
        i++;
    }
}
