#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct s_punto{
    int x;
    int y;
};
void distanciaEntrePuntos(int x1,int y1,int x2,int y2);
void distanciaEntrePuntosConsecutivos(int x,struct s_punto p[]);
void distanciaEntrePuntosCualquiera(int x,struct s_punto p[]);
void cargarStructMatDeArch(int x,struct s_punto p[],FILE *arch);
typedef struct s_punto t_punto;
int main(){
    FILE *arch;
    arch=fopen("puntos.txt","r");
    int tam=10;
    t_punto p[tam];
    cargarStructMatDeArch(tam,p,arch);
    distanciaEntrePuntos(p[0].x,p[0].y,p[1].x,p[1].y);
    distanciaEntrePuntosConsecutivos(tam,p);
    distanciaEntrePuntosCualquiera(tam,p);
    fclose(arch);
    return 0;
}
void cargarStructMatDeArch(int x,struct s_punto p[],FILE *arch){
    int a,r,i=0;
    while(i!=x && r!=EOF){
        r=fscanf(arch,"%d,",&a);
        p[i].x=a;
        if(i==x-1){
            r=fscanf(arch,"%d\n",&a);
            p[i].y=a;
        }else{
            r=fscanf(arch,"%d,",&a);
            p[i].y=a;
        }
        i++;
    }
}
void distanciaEntrePuntos(int x1,int y1,int x2,int y2){
    double a;
    a=sqrt(pow((x1-x2),2)+pow((y1-y2),2));
    printf("la distancia entre (%d,%d) y (%d,%d) es:%.2lf",x1,y1,x2,y2,a);
    printf("\n");
}
void distanciaEntrePuntosConsecutivos(int x,struct s_punto p[]){
    int i=0,j=i+1;
    double a;
    while(i!=x-1){
        a=sqrt(pow((p[i].x-p[j].x),2)+pow((p[i].y-p[j].y),2));
        printf("la distancia entre (%d,%d) y (%d,%d) es:%.2lf",p[i].x,p[i].y,p[j].x,p[j].y,a);
        printf("\n");
        i++;
        j++;
    }
}
void distanciaEntrePuntosCualquiera(int x,struct s_punto p[]){
    int i=0,j=i+1;
    double a;
    while(i!=x-1){
        while(j!=x){
            a=sqrt(pow((p[i].x-p[j].x),2)+pow((p[i].y-p[j].y),2));
            printf("la distancia entre (%d,%d) y (%d,%d) es:%.2lf",p[i].x,p[i].y,p[j].x,p[j].y,a);
            printf("\n");
            j++;
        }
        i++;
        j=i+1;
    }
}
