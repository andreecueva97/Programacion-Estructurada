#include <stdio.h>
#include <stdlib.h>
void representacionBinaria();
int main()
{
    representacionBinaria();
    return 0;
}
void representacionBinaria(){
    int i=0;
    unsigned char x,n;
    x=64;
    n=1;
    n=n<<7;
    while(i!=8){
        if((x&n)==0){
            printf("0");
        }else{
            printf("1");
        }
        i++;
        n=n>>1;
    }
}
