#include <stdio.h>
#include <stdlib.h>
unsigned char cambioDeMinusculaAMayusculaYViceversa(unsigned char letra,unsigned char mascara);
int main()
{
    unsigned char a,b;
    a=97;
    b=32;
    printf("%c",a);
    a=cambioDeMinusculaAMayusculaYViceversa(a,b);
    printf("\n%c",a);
    return 0;
}
unsigned char cambioDeMinusculaAMayusculaYViceversa(unsigned char letra,unsigned char mascara){
    return letra^mascara;
}
