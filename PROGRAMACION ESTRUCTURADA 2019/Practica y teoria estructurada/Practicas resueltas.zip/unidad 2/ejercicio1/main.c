#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct s_punto{
    int x;
    int y;
};
void distanciaAlOrigen(int x1,int y1,int x2,int y2);
typedef struct s_punto t_punto;
int main(){
    t_punto p1,p2;
    printf("Ingrese x1:");
    scanf("%d",&p1.x);
    printf("\n");
    printf("Ingrese y1:");
    scanf("%d",&p1.y);
    printf("\n");
    printf("Ingrese x2:");
    scanf("%d",&p2.x);
    printf("\n");
    printf("Ingrese y2:");
    scanf("%d",&p2.y);
    distanciaAlOrigen(p1.x,p1.y,p2.x,p2.y);
    return 0;
}
void distanciaAlOrigen(int x1,int y1,int x2,int y2){
    double a,b;
    a=sqrt((x1*x1)+(y1*y1));
    b=sqrt((x2*x2)+(y2*y2));
    if(a<b){
        printf("El punto mas cerca al origen es (%d,%d)",x1,y1);
    }
    if(a>b){
        printf("El punto mas cerca al origen es (%d,%d)",x2,y2);
    }
    if(a==b){
        printf("Ambos puntos estan a la misma distancia del origen");
    }
}
