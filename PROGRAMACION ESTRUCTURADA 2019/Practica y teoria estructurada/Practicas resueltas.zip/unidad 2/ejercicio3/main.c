#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct s_tabla{
    char equipo[20];
    int puntos[8];
};
typedef struct s_tabla t_tabla;
void cargarStructArrDeArch(FILE *arch1,FILE *arch2,struct s_tabla t[],int x);
void imprimirTabla(FILE *arch,struct s_tabla t[],int x);
int main(){
    FILE* arch1;
    FILE* arch2;
    FILE* arch3;
    int tam=5;
    t_tabla t[tam];
    arch1=fopen("cabeceras.txt","r");
    arch2=fopen("items.txt","r");
    arch3=fopen("datos.txt","r");
    cargarStructArrDeArch(arch2,arch3,t,tam);
    imprimirTabla(arch1,t,tam);
    fclose(arch1);
    fclose(arch2);
    fclose(arch3);
    return 0;
}
void cargarStructArrDeArch(FILE *arch1,FILE *arch2,struct s_tabla t[],int x){
    int r,i=0,a=0,b=0,c=0;
    char caracter;
    while(i!=x){
        caracter=fgetc(arch1);
        while(caracter!='\n' && caracter!=EOF){
            t[i].equipo[a]=caracter;
            caracter=fgetc(arch1);
            a++;
        }
        t[i].equipo[a]='\0';
        while(b!=8 && r!=EOF){
            if(b==7){
                r=fscanf(arch2,"%d\n",&c);
                t[i].puntos[b]=c;
            }else{
                r=fscanf(arch2,"%d,",&c);
                t[i].puntos[b]=c;
            }
            b++;
        }
        a=0;
        b=0;
        i++;
    }
}
void imprimirTabla(FILE *arch,struct s_tabla t[],int x){
    int a=0,b=0;
    char arr[10],caracter;
    caracter=fgetc(arch);
    while(caracter!=EOF){
        while(caracter!='\n' && caracter!=EOF){
            arr[a]=caracter;
            caracter=fgetc(arch);
            a++;
        }
        arr[a]='\0';
        if(b==0){
            printf("%-14s",arr);
        }else{
            printf("%s  ",arr);
        }
        a=0;
        b++;
        caracter=fgetc(arch);
    }
    a=0;
    b=0;
    printf("\n");
    printf("---------------------------------------------------");
    printf("\n");
    while(a!=x){
        printf("%-13s",t[a].equipo);
        while(b!=8){
            if(t[a].puntos[b]>0 && b==7){
                printf("%+4d",t[a].puntos[b]);
            }else{
                printf("%4d",t[a].puntos[b]);
            }
            b++;
        }
        printf("\n");
        b=0;
        a++;
    }
}
