#include <stdio.h>
#include <stdlib.h>
void shiftDerecha();
int main()
{
    shiftDerecha();
    return 0;
}
void shiftDerecha(){
    int i=0;
    unsigned char n;
    n=1;
    n=n<<7;
    while(i!=8){
        printf("%d\n",n);
        i++;
        n=n>>1;
    }
}
