#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct s_personas{
    int documento;
    char nombre[25],pais[25];
};
typedef struct s_personas t_personas;
void cargarStructArrDeArch(int x,FILE *arch,struct s_personas p[x]);
void imprimirTabla(int x,struct s_personas p[x]);
void ordenarTabla(int x,struct s_personas p[x],int opcion);
int main(){
    FILE *arch;
    int tam=4,opcion;
    t_personas p[tam];
    arch=fopen("personas.txt","r");
    cargarStructArrDeArch(tam,arch,p);
    imprimirTabla(tam,p);
    printf("1- Ver listado ordenado por nombre\n");
    printf("2- Ver listado ordenado por documento\n");
    printf("3- Ver listado ordenado por pais\n");
    printf("4- Salir del programa\n");
    scanf("%d",&opcion);
    while(opcion!=4){
        ordenarTabla(tam,p,opcion);
        imprimirTabla(tam,p);
        printf("1- Ver listado ordenado por nombre\n");
        printf("2- Ver listado ordenado por documento\n");
        printf("3- Ver listado ordenado por pais\n");
        printf("4- Salir del programa\n");
        scanf("%d",&opcion);
    }
    fclose(arch);
    return 0;
}
void cargarStructArrDeArch(int x,FILE *arch,struct s_personas p[x]){
    int a,r,i=0,j=0;
    char caracter;
    r=fscanf(arch,"%d,",&a);
    while(i!=x && r!=EOF){
        p[i].documento=a;
        caracter=getc(arch);
        while(caracter!=',' && caracter!='\n'){
            p[i].nombre[j]=caracter;
            caracter=getc(arch);
            j++;
        }
        p[i].nombre[j]='\0';
        j=0;
        caracter=getc(arch);
        while(caracter!=',' && caracter!='\n'){
            p[i].pais[j]=caracter;
            caracter=getc(arch);
            j++;
        }
        p[i].pais[j]='\0';
        j=0;
        i++;
        r=fscanf(arch,"%d,",&a);
    }
}
void imprimirTabla(int x,struct s_personas p[x]){
    int i=0;
    printf("Documento     ");
    printf("Nombre           ");
    printf("Pais      ");
    printf("\n");
    printf("============================================");
    printf("\n");
    while(i!=x){
        printf("%-14d",p[i].documento);
        printf("%-17s",p[i].nombre);
        printf("%-10s",p[i].pais);
        printf("\n");
        i++;
    }
}
void ordenarTabla(int x,struct s_personas p[x],int opcion){
    int f1=0,f2=f1+1,aux,ret;
    char auxArr[25];
    while(f1!=x){
        while(f2!=x){
            if(opcion==1){
                ret=strcmp(p[f1].nombre,p[f2].nombre);
                if(ret>0){
                    strcpy(auxArr,p[f1].nombre);
                    strcpy(p[f1].nombre,p[f2].nombre);
                    strcpy(p[f2].nombre,auxArr);
                    strcpy(auxArr,p[f1].pais);
                    strcpy(p[f1].pais,p[f2].pais);
                    strcpy(p[f2].pais,auxArr);
                    aux=p[f1].documento;
                    p[f1].documento=p[f2].documento;
                    p[f2].documento=aux;
                }
            }
            if(opcion==2){
                if(p[f1].documento>p[f2].documento){
                    strcpy(auxArr,p[f1].nombre);
                    strcpy(p[f1].nombre,p[f2].nombre);
                    strcpy(p[f2].nombre,auxArr);
                    strcpy(auxArr,p[f1].pais);
                    strcpy(p[f1].pais,p[f2].pais);
                    strcpy(p[f2].pais,auxArr);
                    aux=p[f1].documento;
                    p[f1].documento=p[f2].documento;
                    p[f2].documento=aux;
                }
            }
            if(opcion==3){
                ret=strcmp(p[f1].pais,p[f2].pais);
                if(ret>0){
                    strcpy(auxArr,p[f1].nombre);
                    strcpy(p[f1].nombre,p[f2].nombre);
                    strcpy(p[f2].nombre,auxArr);
                    strcpy(auxArr,p[f1].pais);
                    strcpy(p[f1].pais,p[f2].pais);
                    strcpy(p[f2].pais,auxArr);
                    aux=p[f1].documento;
                    p[f1].documento=p[f2].documento;
                    p[f2].documento=aux;
                }
            }
            f2++;
        }
        f1++;
        f2=f1+1;
    }
}
