#include <stdio.h>
#include <stdlib.h>
void contarBits();
int main()
{
    contarBits();
    return 0;
}
void contarBits(){
    int i=0,contador=0;
    unsigned int x,n;
    x=6;
    n=1;
    n=n<<7;
    while(i!=8){
        if((x&(n>>i))==0){
            printf("0");
        }else{
            printf("1");
            contador++;
        }
        i++;
    }
    printf("\nbits en 1:%d",contador);
}
