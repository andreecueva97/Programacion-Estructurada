#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
typedef struct
{
char nombre[100];
int legajo, materias[30];
}
t_alumno;
typedef struct
{
char nombre[100];
int codigo;
}
t_materia;
typedef struct
{
int legajo_alumno;
int cod_materia,nota;
}
t_nota;
void cargarArchDeAlumnos(FILE *arch);
void cargarArchDeMaterias(FILE *arch);
void cargarArchDeNotas(int x,int y,t_alumno a[x],t_materia m[y],FILE *arch);
void cargarStructArrDeArchDeAlumnos(int x,FILE *arch,t_alumno p[x]);
void cargarStructArrDeArchDeMaterias(int x,FILE *arch,t_materia p[x]);
void cargarStructArrDeArchDeNotas(int x,FILE *arch,t_nota n[x]);
void imprimirNotasDeUnAlumno(int x,int y,int z,t_alumno a[x],t_materia m[y],t_nota n[z],int select);
void imprimirNotasDeUnaMateria(int x,int y,int z,t_alumno a[x],t_materia m[y],t_nota n[z],int select);
int main()
{
    FILE *arch1;
    FILE *arch2;
    FILE *arch3;
    arch1=fopen("alumnos.txt","a+");
    arch2=fopen("materias.txt","a+");
    arch3=fopen("notas.txt","w+");
    int tam1=3,tam2=8,tam3=tam1*tam2;
    t_alumno a[tam1];
    t_materia m[tam2];
    t_nota n[tam3];
    cargarArchDeAlumnos(arch1);
    cargarArchDeMaterias(arch2);
    cargarStructArrDeArchDeAlumnos(tam1,arch1,a);
    cargarStructArrDeArchDeMaterias(tam2,arch2,m);
    cargarArchDeNotas(tam1,tam2,a,m,arch3);
    fclose(arch3);
    arch3=fopen("notas.txt","r");
    cargarStructArrDeArchDeNotas(tam3,arch3,n);
    imprimirNotasDeUnAlumno(tam1,tam2,tam3,a,m,n,a[0].legajo);
    imprimirNotasDeUnaMateria(tam1,tam2,tam3,a,m,n,m[0].codigo);
    fclose(arch1);
    fclose(arch2);
    fclose(arch3);
    return 0;
}
void cargarArchDeAlumnos(FILE *arch){
    int legajo=1,materia,a=0;
    char caracter;
    while(legajo!=0){
        printf("ingrese el numero del legajo:");
        scanf("%d",&legajo);
        if(legajo!=0){
            a=0;
            fprintf(arch,"%d,",legajo);
            printf("ingrese los codigos de las materias del alumno:");
            scanf("%d",&materia);
            while(materia<0){
                printf("\nError. Ingrese un codigo valido:");
                scanf("%d",&materia);
            }
            while(a!=30 && materia!=0){
                fprintf(arch,"%d,",materia);
                scanf("%d",&materia);
                while(materia<0){
                    printf("\nError. Ingrese un codigo valido:");
                    scanf("%d,",&materia);
                }
                a++;
                if(materia==0){
                    while(a!=30){
                        fprintf(arch,"%d,",materia);
                        a++;
                    }
                }
            }
            printf("\n");
            printf("ingrese el nombre del alumno:");
            caracter=getche();
            while(caracter!='\r'){
                fprintf(arch,"%c",caracter);
                caracter=getche();
            }
            fprintf(arch,"\n");
            printf("\n");
        }
    }
}
void cargarArchDeMaterias(FILE *arch){
    int codigo=1;
    char caracter;
    while(codigo!=0){
        printf("ingrese el codigo de la materia:");
        scanf("%d",&codigo);
        while(codigo<0){
            printf("\nError. Ingrese un codigo valido:");
            scanf("%d,",&codigo);
        }
        if(codigo!=0){
            fprintf(arch,"%d,",codigo);
            printf("ingrese el nombre de la materia:");
            caracter=getche();
            while(caracter!='\r'){
                fprintf(arch,"%c",caracter);
                caracter=getche();
            }
            fprintf(arch,"\n");
            printf("\n");
        }
    }
}
void cargarStructArrDeArchDeMaterias(int x,FILE *arch,t_materia p[x]){
    int a,r,i=0,j=0;
    char caracter;
    r=fscanf(arch,"%d,",&a);
    while(i!=x && r!=EOF){
        p[i].codigo=a;
        caracter=getc(arch);
        while(caracter!='\n' && caracter!=EOF){
            p[i].nombre[j]=caracter;
            caracter=getc(arch);
            j++;
        }
        p[i].nombre[j]='\0';
        j=0;
        i++;
        r=fscanf(arch,"%d,",&a);
    }
    if(i<x){
        p[i].codigo=0;
    }
}
void cargarStructArrDeArchDeAlumnos(int x,FILE *arch,t_alumno p[x]){
    int a,r,i=0,j=0;
    char caracter;
    r=fscanf(arch,"%d,",&a);
    while(i!=x && r!=EOF){
        p[i].legajo=a;
        while(j!=30){
            r=fscanf(arch,"%d,",&a);
            p[i].materias[j]=a;
            j++;
        }
        j=0;
        caracter=getc(arch);
        while(caracter!='\n' && caracter!=EOF){
            p[i].nombre[j]=caracter;
            caracter=getc(arch);
            j++;
        }
        p[i].nombre[j]='\0';
        j=0;
        i++;
        r=fscanf(arch,"%d,",&a);
    }
    if(i<x){
        p[i].legajo=0;
    }
}
void cargarArchDeNotas(int x,int y,t_alumno a[x],t_materia m[y],FILE *arch){
    int i=0,j=0,h=0,nota;
    while(i!=x && a[i].legajo!=0){
        while(a[i].materias[j]!=0){
            while(a[i].materias[j]!=m[h].codigo){
                h++;
            }
            printf("Ingrese la nota de %s para la materia %s:",a[i].nombre,m[h].nombre);
            scanf("%d",&nota);
            fprintf(arch,"%d,%d,%d\n",a[i].legajo,m[h].codigo,nota);
            j++;
            h=0;
        }
        i++;
        j=0;
    }
}
void cargarStructArrDeArchDeNotas(int x,FILE *arch,t_nota n[x]){
    int i=0,r,a,b,c;
    r=fscanf(arch,"%d,%d,%d\n",&a,&b,&c);
    while(i!=x && r!=EOF){
        n[i].legajo_alumno=a;
        n[i].cod_materia=b;
        n[i].nota=c;
        r=fscanf(arch,"%d,%d,%d\n",&a,&b,&c);
        i++;
    }
    if(i<x){
        n[i].legajo_alumno=0;
    }
}
void imprimirNotasDeUnAlumno(int x,int y,int z,t_alumno a[x],t_materia m[y],t_nota n[z],int select){
    int i=0,j=0;
    while(i!=x && a[i].legajo!=0){
        if(a[i].legajo==select){
            printf("Las notas de alumno %s son:\n",a[i].nombre);
        }
        i++;
    }
    i=0;
    while(i!=z && n[i].legajo_alumno!=0){
        if(n[i].legajo_alumno==select){
            while(j!=y && m[j].codigo!=0){
                if(m[j].codigo==n[i].cod_materia){
                    printf("%s:",m[j].nombre);
                }
                j++;
            }
            printf("%d\n",n[i].nota);
        }
        i++;
        j=0;
    }
}
void imprimirNotasDeUnaMateria(int x,int y,int z,t_alumno a[x],t_materia m[y],t_nota n[z],int select){
    int i=0,j=0;
    while(i!=y && a[i].legajo!=0){
        if(m[i].codigo==select){
            printf("Las notas de la materia %s son:\n",m[i].nombre);
        }
        i++;
    }
    i=0;
    while(i!=z && n[i].legajo_alumno!=0){
        if(n[i].cod_materia==select){
            while(j!=x && a[j].legajo!=0){
                if(a[j].legajo==n[i].legajo_alumno){
                        printf("%s:",a[j].nombre);
                        printf("%d\n",n[i].nota);
                }
                j++;
            }
        }
        i++;
        j=0;
    }
}
