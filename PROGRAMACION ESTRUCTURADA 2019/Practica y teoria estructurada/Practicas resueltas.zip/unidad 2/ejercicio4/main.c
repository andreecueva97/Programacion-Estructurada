#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
void cargarArch(FILE *arch);
int main()
{
    FILE *arch;
    arch=fopen("personas.txt","w");
    cargarArch(arch);
    fclose(arch);
    return 0;
}
void cargarArch(FILE *arch){
    int documento;
    char caracter;
    while(documento!=0){
        printf("ingrese el numero del documento:");
        scanf("%d",&documento);
        if(documento!=0){
            fprintf(arch,"%d,",documento);
            printf("ingrese el nombre de la persona:");
            caracter=getche();
            while(caracter!='\r'){
                fprintf(arch,"%c",caracter);
                caracter=getche();
            }
            fprintf(arch,",");
            printf("\n");
            printf("ingrese el pais de la persona:");
            caracter=getche();
            while(caracter!='\r'){
                fprintf(arch,"%c",caracter);
                caracter=getche();
            }
            fprintf(arch,"\n");
            printf("\n");
        }
    }
}
